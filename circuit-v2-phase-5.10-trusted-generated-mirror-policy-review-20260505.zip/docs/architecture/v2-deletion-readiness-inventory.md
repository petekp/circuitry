# Core-v2 Deletion Readiness Inventory

Date: 2026-05-05

## Summary

Phase 5.5 is an inventory pass only.

No old runtime deletion is approved here. No product policy changes are approved
here. No review packet was prepared because this phase does not move from
inventory into deletion or policy change.

The checked hypotheses were:

1. Some `src/runtime` files might now be tiny deletion candidates after Build
   deep moved to core-v2 by default.
2. Some `src/runtime` files are neutral infrastructure under an old namespace,
   not old runner code.
3. Some retained runner or handler tests might now be obsolete because v2 has
   matching coverage.

The result:

- no `src/runtime` file is a current deletion candidate;
- no retained runner or handler test is obsolete;
- several files are only compatibility wrappers, but old-path imports still
  make them intentional support surfaces;
- several files should move to neutral ownership later, but only behind focused
  review.

## File Labels

| Label | Meaning |
|---|---|
| compatibility wrapper | Old import path that re-exports a neutral module or preserves an old public surface. |
| retained fallback | Old execution behavior still reached by unsupported modes, rollback, arbitrary fixtures, `composeWriter`, or retained checkpoints. |
| retained product behavior | Durable retained behavior for run folders, traces, status, progress, snapshots, results, or checkpoint resume. |
| oracle/test support | Old behavior retained mainly as a comparison oracle or direct low-level proof. |
| neutral-move candidate | Live shared infrastructure that should probably leave `src/runtime`, but is not deletable. |
| tiny deletion candidate | Small file that can be deleted after import repair and proof. |
| blocker/unknown | Current owner is unclear enough to block deletion planning. |

## Runtime File Disposition

| Path | Classification | Why |
|---|---|---|
| `src/runtime/append-and-derive.ts` | retained product behavior | Appends retained trace entries and derives retained snapshots. Keep while retained trace/state is live. |
| `src/runtime/catalog-derivations.ts` | neutral-move candidate | Builds registries from the flow catalog. It is authoring/flow-package infrastructure, not old runner debris. |
| `src/runtime/checkpoint-resume.ts` | retained product behavior | Owns retained/v1 checkpoint resume preparation. Keep while old checkpoint folders remain supported. |
| `src/runtime/compile-schematic-to-flow.ts` | neutral-move candidate | The compiler and generated-flow emitter still use it. Move only through a compiler ownership plan. |
| `src/runtime/config-loader.ts` | compatibility wrapper | Neutral config loading lives in `src/shared/config-loader.ts`; keep old path until imports retire. |
| `src/runtime/connectors/claude-code.ts` | neutral-move candidate | Live subprocess connector used by retained runtime and v2 connector bridge. Move only with connector plan. |
| `src/runtime/connectors/codex.ts` | neutral-move candidate | Live subprocess connector used by retained runtime and v2 connector bridge. Move only with connector plan. |
| `src/runtime/connectors/custom.ts` | neutral-move candidate | Live custom connector subprocess support. Move only with connector plan. |
| `src/runtime/connectors/relay-materializer.ts` | neutral-move candidate | Live relay materialization and trace-shape safety. Move only with connector/materializer review. |
| `src/runtime/connectors/shared.ts` | compatibility wrapper | Re-exports shared connector helpers and relay types for old imports. |
| `src/runtime/manifest-snapshot-writer.ts` | compatibility wrapper | Neutral byte-match helper lives in `src/shared/manifest-snapshot.ts`; keep old path for retained imports/tests. |
| `src/runtime/operator-summary-writer.ts` | compatibility wrapper | Neutral operator summary writer lives in `src/shared/operator-summary-writer.ts`; keep old path for compatibility. |
| `src/runtime/policy/flow-kind-policy.ts` | compatibility wrapper | Neutral policy helper lives in `src/shared/flow-kind-policy.ts`; keep old path for imports/docs. |
| `src/runtime/progress-projector.ts` | retained product behavior | Retained trace-to-progress projection is still needed for retained runs and old folders. |
| `src/runtime/reducer.ts` | retained product behavior | Retained trace reduction remains the state authority for retained/v1 runs. |
| `src/runtime/registries/checkpoint-writers/registry.ts` | neutral-move candidate | Live checkpoint writer lookup used by retained and v2 paths. |
| `src/runtime/registries/checkpoint-writers/types.ts` | neutral-move candidate | Flow packages and tests import the type surface. |
| `src/runtime/registries/close-writers/registry.ts` | neutral-move candidate | Live close writer lookup used by retained and v2 paths. |
| `src/runtime/registries/close-writers/shared.ts` | neutral-move candidate | Shared report-path helpers used by flow writers and validators. |
| `src/runtime/registries/close-writers/types.ts` | neutral-move candidate | Flow packages and tests import the type surface. |
| `src/runtime/registries/compose-writers/registry.ts` | neutral-move candidate | Live compose writer lookup used by retained and v2 paths. |
| `src/runtime/registries/compose-writers/types.ts` | neutral-move candidate | Flow packages and tests import the type surface. |
| `src/runtime/registries/cross-report-validators.ts` | neutral-move candidate | Live validator registry used by retained relay/fanout and v2 relay. |
| `src/runtime/registries/report-schemas.ts` | neutral-move candidate | Live report parsing surface used by retained and v2 paths. |
| `src/runtime/registries/shape-hints/registry.ts` | neutral-move candidate | Live relay shape-hint lookup used by shared relay support. |
| `src/runtime/registries/shape-hints/types.ts` | neutral-move candidate | Flow packages import the type surface. |
| `src/runtime/registries/verification-writers/registry.ts` | neutral-move candidate | Live verification writer lookup used by retained and v2 paths. |
| `src/runtime/registries/verification-writers/types.ts` | neutral-move candidate | Flow packages and tests import the type surface. |
| `src/runtime/relay-selection.ts` | retained fallback | Retained relay decision bridge and connector resolution remain live for fallback paths. |
| `src/runtime/relay-support.ts` | compatibility wrapper | Neutral relay support lives in `src/shared/relay-support.ts`; keep old path for retained handler imports. |
| `src/runtime/result-writer.ts` | retained product behavior | Retained result writer is still used by old runner, sub-run, fanout, and compatibility tests. |
| `src/runtime/router.ts` | neutral-move candidate | Natural-language flow routing is product infrastructure, not retained execution. Move only with router/catalog plan. |
| `src/runtime/run-relative-path.ts` | compatibility wrapper | Neutral helper lives in `src/shared/run-relative-path.ts`; keep old path for retained imports/tests. |
| `src/runtime/run-status-projection.ts` | compatibility wrapper | Neutral dispatcher lives in `src/run-status/project-run-folder.ts`; keep old path for compatibility tests. |
| `src/runtime/runner-types.ts` | compatibility wrapper | Shared relay/progress types moved to `src/shared/relay-runtime-types.ts`, but retained invocation/result types still live here. |
| `src/runtime/runner.ts` | retained fallback | Owns fallback execution, rollback execution, arbitrary fixtures, `composeWriter`, and public retained resume wrapper. |
| `src/runtime/selection-resolver.ts` | compatibility wrapper | Neutral resolver lives in `src/shared/selection-resolver.ts`; keep old path for imports/tests. |
| `src/runtime/snapshot-writer.ts` | retained product behavior | Retained snapshot derivation is live for retained runs, handoff, and old checkpoint folders. |
| `src/runtime/step-handlers/checkpoint.ts` | retained product behavior | Retained checkpoint waiting/resume behavior remains supported for retained/v1 folders and unproven modes. |
| `src/runtime/step-handlers/compose.ts` | retained fallback | Keeps retained compose behavior and the public `composeWriter` hook. |
| `src/runtime/step-handlers/fanout.ts` | retained fallback | Retained fanout execution remains fallback/oracle coverage for unretired paths. |
| `src/runtime/step-handlers/fanout/aggregate.ts` | retained fallback | Helper for retained fanout aggregation. |
| `src/runtime/step-handlers/fanout/branch-resolution.ts` | retained fallback | Helper for retained fanout branch expansion and path safety. |
| `src/runtime/step-handlers/fanout/join-policy.ts` | oracle/test support | Pure join-policy helper remains useful as retained/v2 comparison proof. It is not deletion-ready. |
| `src/runtime/step-handlers/fanout/types.ts` | retained fallback | Type support for retained fanout behavior. |
| `src/runtime/step-handlers/index.ts` | retained fallback | Dispatcher for retained step handlers. |
| `src/runtime/step-handlers/recovery-route.ts` | retained fallback | Shared retained handler recovery routing. |
| `src/runtime/step-handlers/relay.ts` | retained fallback | Retained relay execution, materialization, validation, and connector bridge behavior. |
| `src/runtime/step-handlers/shared.ts` | retained fallback | Shared retained handler report/path helpers. |
| `src/runtime/step-handlers/sub-run.ts` | retained fallback | Retained sub-run execution remains fallback/oracle coverage. |
| `src/runtime/step-handlers/types.ts` | retained fallback | Type support for the retained handler cluster. |
| `src/runtime/step-handlers/verification.ts` | retained fallback | Retained verification execution remains fallback/oracle coverage. |
| `src/runtime/terminal-verdict.ts` | retained product behavior | Pure helper used by retained close/result finalization. |
| `src/runtime/trace-reader.ts` | retained product behavior | Retained trace reading remains live for retained status, progress, resume, and tests. |
| `src/runtime/trace-writer.ts` | retained product behavior | Retained trace appending remains live for retained runs and tests. |
| `src/runtime/write-capable-worker-disclosure.ts` | compatibility wrapper | Neutral helper lives in `src/shared/write-capable-worker-disclosure.ts`; keep old path for compatibility. |

## Category Totals

| Category | Count | Current deletion-ready count |
|---|---:|---:|
| compatibility wrapper | 11 | 0 |
| retained fallback | 14 | 0 |
| retained product behavior | 10 | 0 |
| oracle/test support | 1 | 0 |
| neutral-move candidate | 20 | 0 |
| tiny deletion candidate | 0 | 0 |
| blocker/unknown | 0 | 0 |

No unknown owner remains after this inventory. That does not mean deletion is
ready. It means the blockers are known and policy-shaped.

## Retained Runner And Handler Test Disposition

| Bucket | Tests | Decision |
|---|---|---|
| retained fallback coverage | `tests/runner/agent-relay-roundtrip.test.ts`, `tests/runner/build-checkpoint-exec.test.ts`, `tests/runner/build-runtime-wiring.test.ts`, `tests/runner/check-evaluation.test.ts`, `tests/runner/checkpoint-handler-direct.test.ts`, `tests/runner/cli-v2-runtime.test.ts`, `tests/runner/codex-relay-roundtrip.test.ts`, `tests/runner/fresh-run-root.test.ts`, `tests/runner/handler-throw-recovery.test.ts`, `tests/runner/materializer-schema-parse.test.ts`, `tests/runner/pass-route-cycle-guard.test.ts`, `tests/runner/push-sequence-authority.test.ts`, `tests/runner/relay-invocation-failure.test.ts`, `tests/runner/run-relative-path.test.ts`, `tests/runner/run-status-projection.test.ts`, `tests/runner/runner-relay-connector-identity.test.ts`, `tests/runner/runner-relay-provenance.test.ts`, `tests/runner/runtime-smoke.test.ts`, `tests/runner/terminal-outcome-mapping.test.ts`, `tests/runner/terminal-verdict-derivation.test.ts`, `tests/runner/terminal-verdict-helper.test.ts`, `tests/runner/utility-cli.test.ts`, `tests/unit/runtime/event-log-round-trip.test.ts`, `tests/unit/runtime/progress-projector.test.ts` | Keep. These prove behavior still reached by retained/v1 folders, rollback, unsupported rows, retained status/progress, or compatibility surfaces. |
| oracle coverage | `tests/runner/build-report-writer.test.ts`, `tests/runner/build-verification-exec.test.ts`, `tests/runner/close-builder-registry.test.ts`, `tests/runner/compose-builder-registry.test.ts`, `tests/runner/explore-e2e-parity.test.ts`, `tests/runner/explore-report-writer.test.ts`, `tests/runner/explore-tournament-runtime.test.ts`, `tests/runner/fanout-handler-direct.test.ts`, `tests/runner/fanout-real-recursion.test.ts`, `tests/runner/fanout-runtime.test.ts`, `tests/runner/fix-report-writer.test.ts`, `tests/runner/fix-runtime-wiring.test.ts`, `tests/runner/migrate-runtime-wiring.test.ts`, `tests/runner/relay-handler-direct.test.ts`, `tests/runner/review-runtime-wiring.test.ts`, `tests/runner/sub-run-handler-direct.test.ts`, `tests/runner/sub-run-real-recursion.test.ts`, `tests/runner/sub-run-runtime.test.ts`, `tests/runner/sweep-runtime-wiring.test.ts`, `tests/runner/verification-handler-direct.test.ts`, `tests/properties/visible/fanout-join-policy.test.ts` | Keep. These are still comparison proof for behavior v2 must preserve or deliberately retire. |
| migrated to v2 | none of the retained runner/handler tests | V2 coverage exists in `tests/core-v2/` and `tests/soak/`, but it does not make these retained tests deletable yet. |
| obsolete candidate | none | No retained runner or handler test is obsolete in this pass. |

Compatibility-import tests such as `tests/runner/config-loader.test.ts`,
`tests/runner/connector-shared-compat.test.ts`,
`tests/runner/operator-summary-writer.test.ts`,
`tests/runner/result-path-compat.test.ts`, and
`tests/runner/run-status-facade.test.ts` are not runner deletion blockers by
themselves, but they keep old import paths intentional until those paths are
retired.

## Deletion Blockers

Old runtime deletion remains blocked by live responsibilities:

- retained/v1 checkpoint folder resume;
- unsupported flow/mode/depth fallback;
- arbitrary explicit fixture fallback;
- programmatic `composeWriter` retained-runtime-only compatibility;
- rollback through `CIRCUIT_DISABLE_V2_RUNTIME=1`;
- retained trace, reducer, snapshot, progress, status, result, and checkpoint
  behavior;
- connector subprocesses and relay materialization still under `src/runtime`;
- registries, router, catalog, and compiler modules still under `src/runtime`;
- retained runner and handler tests that are still fallback or oracle proof.

Runtime decision diagnostics are not an old runtime deletion blocker by
themselves. Phase 5.8.1 adds `CIRCUIT_SHOW_RUNTIME_DECISION=1` and keeps
`CIRCUIT_V2_RUNTIME_CANDIDATE=1` as a temporary alias, but that does not move or
delete retained execution code.

## Next Useful Slices

The next deletion-adjacent work should not delete files. Pick one narrow
decision at a time:

1. Decide whether rollback is a permanent operator safety feature.
2. Plan neutral ownership for registries, connector subprocesses, relay
   materialization, router, catalog, or compiler modules before moving them.
3. Keep retained/v1 checkpoint folders supported unless a migration or
   retirement plan is approved.

Phase 5.7 resolved the programmatic `composeWriter` disposition without making
old runtime deletion possible: `composeWriter` remains retained-runtime-only
compatibility and should not be cloned into core-v2.

Phase 5.8.1 implements the runtime decision diagnostics rename:
`CIRCUIT_SHOW_RUNTIME_DECISION=1` is preferred and
`CIRCUIT_V2_RUNTIME_CANDIDATE=1` remains a temporary alias. The alias itself can
be removed later only by an explicit operator-facing slice.

Phase 5.9 resolves the arbitrary fixture disposition without making deletion
possible: arbitrary explicit fixtures, custom flow roots, and packaged host flow
roots remain retained-runtime-owned by default unless a future trusted-root or
deprecation policy explicitly changes that.
