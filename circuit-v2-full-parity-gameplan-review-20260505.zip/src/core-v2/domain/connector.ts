export type ConnectorRef = string;
