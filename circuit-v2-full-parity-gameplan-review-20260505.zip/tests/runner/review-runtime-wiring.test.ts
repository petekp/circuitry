import { execFileSync } from 'node:child_process';
import {
  chmodSync,
  existsSync,
  mkdirSync,
  mkdtempSync,
  readFileSync,
  rmSync,
  writeFileSync,
} from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';

import {
  type ReviewFinding,
  ReviewIntake,
  ReviewRelayResult,
  ReviewResult,
  type ReviewResultVerdict,
  computeReviewVerdict,
} from '../../src/flows/review/reports.js';
import type { ChangeKindDeclaration } from '../../src/schemas/change-kind.js';
import { CompiledFlow } from '../../src/schemas/compiled-flow.js';
import { RunId } from '../../src/schemas/ids.js';
import { ProgressEvent } from '../../src/schemas/progress-event.js';

import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
import type { RelayResult } from '../../src/runtime/connectors/shared.js';
import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';

const FIXTURE_PATH = resolve('.claude-plugin', 'skills', 'review', 'circuit.json');

function loadFixture(): { flow: CompiledFlow; bytes: Buffer } {
  const bytes = readFileSync(FIXTURE_PATH);
  const raw: unknown = JSON.parse(bytes.toString('utf8'));
  return { flow: CompiledFlow.parse(raw), bytes };
}

function loadFixtureWithRenamedAnalyzeResultPath(resultPath: string): {
  flow: CompiledFlow;
  bytes: Buffer;
} {
  const raw = JSON.parse(readFileSync(FIXTURE_PATH, 'utf8')) as {
    steps: Array<{
      id: string;
      writes?: { result?: string };
      reads?: string[];
    }>;
  };
  for (const step of raw.steps) {
    if (step.id === 'audit-step' && step.writes !== undefined) {
      step.writes.result = resultPath;
    }
    if (step.id === 'verdict-step' && step.reads !== undefined) {
      step.reads = step.reads.map((path) =>
        path === 'stages/analyze/review-raw-findings.json' ? resultPath : path,
      );
    }
  }
  const bytes = Buffer.from(`${JSON.stringify(raw, null, 2)}\n`);
  return { flow: CompiledFlow.parse(raw), bytes };
}

function deterministicNow(startMs: number): () => Date {
  let n = 0;
  return () => new Date(startMs + n++ * 1000);
}

function change_kind(): ChangeKindDeclaration {
  return {
    change_kind: 'ratchet-advance',
    failure_mode:
      'the review fixture could parse statically but fail to run through relay, verdict gating, and close report materialization',
    acceptance_evidence:
      'review-runtime-wiring test runs the live review fixture with a stub relayer and the default registered review compose writer, then parses review.result@v1',
    alternate_framing:
      'keep the injected writer as the only schema-valid path — rejected because P2.9 closed with per-flow compose-writer registration as the named follow-on',
  };
}

function relayerWith(result: ReviewRelayResult): RelayFn {
  return relayerWithBody(JSON.stringify(result));
}

function relayerWithBody(body: string): RelayFn {
  return {
    connectorName: 'claude-code',
    relay: async (input: ClaudeCodeRelayInput): Promise<RelayResult> => {
      expect(input.prompt).toContain('Accepted verdicts: NO_ISSUES_FOUND, ISSUES_FOUND');
      expect(input.prompt).toContain('"findings"');
      expect(input.prompt).toContain('"findings": []');
      expect(input.prompt).toContain('"severity": "<critical|high|low>"');
      expect(input.prompt).not.toContain('medium');
      expect(input.prompt).not.toContain('info');
      return {
        request_payload: input.prompt,
        receipt_id: 'stub-receipt-review',
        result_body: body,
        duration_ms: 1,
        cli_version: '0.0.0-stub',
      };
    },
  };
}

function traceEntryLabel(trace_entry: { kind: string; step_id?: unknown }): string {
  return typeof trace_entry.step_id === 'string'
    ? `${trace_entry.kind}:${trace_entry.step_id}`
    : trace_entry.kind;
}

let runFolderBase: string;

const CASES: Array<{
  name: string;
  runId: string;
  relay: ReviewRelayResult;
  expectedVerdict: ReviewResultVerdict;
}> = [
  {
    name: 'clean review',
    runId: '79000000-0000-0000-0000-000000000001',
    relay: { verdict: 'NO_ISSUES_FOUND', findings: [] },
    expectedVerdict: 'CLEAN',
  },
  {
    name: 'review with high finding',
    runId: '79000000-0000-0000-0000-000000000002',
    relay: {
      verdict: 'ISSUES_FOUND',
      findings: [
        {
          severity: 'high',
          id: 'REVIEW-HIGH-1',
          text: 'High severity issue found by the reviewer.',
          file_refs: ['src/example.ts:12'],
        },
      ] satisfies ReviewFinding[],
    },
    expectedVerdict: 'ISSUES_FOUND',
  },
];

beforeEach(() => {
  runFolderBase = mkdtempSync(join(tmpdir(), 'circuit-next-review-runtime-'));
});

afterEach(() => {
  rmSync(runFolderBase, { recursive: true, force: true });
});

describe('registered review compose writer', () => {
  it('writes schema-valid review.result with the default compose writer', async () => {
    const { flow, bytes } = loadFixture();
    const runFolder = join(runFolderBase, 'default-registered-review-writer');
    const goal = 'Review scope with the default registered compose writer';

    const outcome = await runCompiledFlow({
      runFolder,
      flow,
      flowBytes: bytes,
      runId: RunId.parse('79000000-0000-0000-0000-000000000000'),
      goal,
      depth: 'standard',
      change_kind: change_kind(),
      now: deterministicNow(Date.UTC(2026, 3, 24, 14, 0, 0)),
      relayer: relayerWith({ verdict: 'NO_ISSUES_FOUND', findings: [] }),
    });

    expect(outcome.result.outcome).toBe('complete');

    const reportPath = join(runFolder, 'reports', 'review-result.json');
    expect(existsSync(reportPath)).toBe(true);
    const report = ReviewResult.parse(JSON.parse(readFileSync(reportPath, 'utf8')));
    expect(report).toEqual({
      scope: goal,
      findings: [],
      verdict: 'CLEAN',
      evidence_summary: {
        kind: 'unavailable',
        message: 'CompiledFlowInvocation.projectRoot was not provided',
      },
      evidence_warnings: [
        {
          kind: 'evidence_unavailable',
          message: 'CompiledFlowInvocation.projectRoot was not provided',
        },
      ],
    });
  });

  it('passes working tree evidence into the reviewer relay when projectRoot is available', async () => {
    const { flow, bytes } = loadFixture();
    const runFolder = join(runFolderBase, 'working-tree-evidence');
    const projectRoot = join(runFolderBase, 'project');
    mkdirSync(join(projectRoot, 'src'), { recursive: true });
    execFileSync('git', ['init'], { cwd: projectRoot, stdio: 'pipe' });
    writeFileSync(join(projectRoot, 'src', 'review-target.ts'), 'const answer = 42;\n');
    execFileSync('git', ['add', 'src/review-target.ts'], { cwd: projectRoot, stdio: 'pipe' });

    const outcome = await runCompiledFlow({
      runFolder,
      flow,
      flowBytes: bytes,
      runId: RunId.parse('79000000-0000-0000-0000-000000000005'),
      goal: 'review the current changes',
      depth: 'standard',
      change_kind: change_kind(),
      now: deterministicNow(Date.UTC(2026, 3, 24, 14, 0, 0)),
      projectRoot,
      relayer: {
        connectorName: 'claude-code',
        relay: async (input: ClaudeCodeRelayInput): Promise<RelayResult> => {
          expect(input.prompt).toContain('"kind": "git-working-tree"');
          expect(input.prompt).toContain('"status_short"');
          expect(input.prompt).toContain('src/review-target.ts');
          expect(input.prompt).toContain('+const answer = 42;');
          return {
            request_payload: input.prompt,
            receipt_id: 'stub-receipt-review-evidence',
            result_body: JSON.stringify({ verdict: 'NO_ISSUES_FOUND', findings: [] }),
            duration_ms: 1,
            cli_version: '0.0.0-stub',
          };
        },
      },
    });

    expect(outcome.result.outcome).toBe('complete');
  });

  it('omits untracked file contents by default while keeping path metadata', async () => {
    const { flow, bytes } = loadFixture();
    const runFolder = join(runFolderBase, 'untracked-metadata-only');
    const projectRoot = join(runFolderBase, 'metadata-only-project');
    const secret = 'secret-like scratch content must not be relayed by default';
    mkdirSync(projectRoot, { recursive: true });
    execFileSync('git', ['init'], { cwd: projectRoot, stdio: 'pipe' });
    writeFileSync(join(projectRoot, 'scratch-notes.txt'), `${secret}\n`);

    const outcome = await runCompiledFlow({
      runFolder,
      flow,
      flowBytes: bytes,
      runId: RunId.parse('79000000-0000-0000-0000-000000000009'),
      goal: 'review the current untracked files',
      depth: 'standard',
      change_kind: change_kind(),
      now: deterministicNow(Date.UTC(2026, 3, 24, 14, 0, 0)),
      projectRoot,
      relayer: {
        connectorName: 'claude-code',
        relay: async (input: ClaudeCodeRelayInput): Promise<RelayResult> => {
          expect(input.prompt).toContain('scratch-notes.txt');
          expect(input.prompt).toContain('"untracked_content_policy": "metadata-only"');
          expect(input.prompt).not.toContain(secret);
          return {
            request_payload: input.prompt,
            receipt_id: 'stub-receipt-review-metadata-only',
            result_body: JSON.stringify({ verdict: 'NO_ISSUES_FOUND', findings: [] }),
            duration_ms: 1,
            cli_version: '0.0.0-stub',
          };
        },
      },
    });

    expect(outcome.result.outcome).toBe('complete');
    const intake = ReviewIntake.parse(
      JSON.parse(readFileSync(join(runFolder, 'reports', 'review-intake.json'), 'utf8')),
    );
    expect(intake.evidence.kind).toBe('git-working-tree');
    if (intake.evidence.kind !== 'git-working-tree') return;
    expect(intake.evidence.untracked_content_policy).toBe('metadata-only');
    expect(intake.evidence.untracked_files).toContainEqual({
      path: 'scratch-notes.txt',
      byte_length: Buffer.byteLength(`${secret}\n`),
    });
    expect(intake.evidence_warnings).toContainEqual(
      expect.objectContaining({ kind: 'untracked_file_content_omitted' }),
    );
  });

  it('includes untracked file contents only with explicit evidence policy opt-in', async () => {
    const { flow, bytes } = loadFixture();
    const runFolder = join(runFolderBase, 'untracked-content-opt-in');
    const projectRoot = join(runFolderBase, 'content-opt-in-project');
    const scratch = 'operator explicitly allowed this untracked content';
    mkdirSync(projectRoot, { recursive: true });
    execFileSync('git', ['init'], { cwd: projectRoot, stdio: 'pipe' });
    writeFileSync(join(projectRoot, 'scratch-notes.txt'), `${scratch}\n`);

    const outcome = await runCompiledFlow({
      runFolder,
      flow,
      flowBytes: bytes,
      runId: RunId.parse('79000000-0000-0000-0000-000000000010'),
      goal: 'review the current untracked files',
      depth: 'standard',
      evidencePolicy: { includeUntrackedFileContent: true },
      change_kind: change_kind(),
      now: deterministicNow(Date.UTC(2026, 3, 24, 14, 0, 0)),
      projectRoot,
      relayer: {
        connectorName: 'claude-code',
        relay: async (input: ClaudeCodeRelayInput): Promise<RelayResult> => {
          expect(input.prompt).toContain('"untracked_content_policy": "include-content"');
          expect(input.prompt).toContain(scratch);
          return {
            request_payload: input.prompt,
            receipt_id: 'stub-receipt-review-content-opt-in',
            result_body: JSON.stringify({ verdict: 'NO_ISSUES_FOUND', findings: [] }),
            duration_ms: 1,
            cli_version: '0.0.0-stub',
          };
        },
      },
    });

    expect(outcome.result.outcome).toBe('complete');
    const intake = ReviewIntake.parse(
      JSON.parse(readFileSync(join(runFolder, 'reports', 'review-intake.json'), 'utf8')),
    );
    expect(intake.evidence.kind).toBe('git-working-tree');
    if (intake.evidence.kind !== 'git-working-tree') return;
    expect(intake.evidence.untracked_content_policy).toBe('include-content');
    expect(intake.evidence.untracked_files[0]).toMatchObject({
      path: 'scratch-notes.txt',
      content: { text: `${scratch}\n`, truncated: false },
    });
    expect(intake.evidence_warnings).not.toContainEqual(
      expect.objectContaining({ kind: 'untracked_file_content_omitted' }),
    );
    const report = ReviewResult.parse(
      JSON.parse(readFileSync(join(runFolder, 'reports', 'review-result.json'), 'utf8')),
    );
    expect(report.evidence_summary).toMatchObject({
      kind: 'git-working-tree',
      untracked_content_policy: 'include-content',
      untracked_file_count: 1,
      untracked_files_sampled: 1,
      untracked_files_truncated: false,
    });
  });

  it('keeps review evidence from large diffs instead of replacing it with a git buffer error', async () => {
    const { flow, bytes } = loadFixture();
    const runFolder = join(runFolderBase, 'large-diff-evidence');
    const projectRoot = join(runFolderBase, 'large-diff-project');
    mkdirSync(join(projectRoot, 'src'), { recursive: true });
    execFileSync('git', ['init'], { cwd: projectRoot, stdio: 'pipe' });

    const marker = 'large-review-diff-marker';
    writeFileSync(join(projectRoot, 'src', 'large-review-target.txt'), `${marker}\n`);
    const largeBody = `${marker}-${'x'.repeat(11 * 1024 * 1024)}\n`;
    writeFileSync(join(projectRoot, 'src', 'large-review-target.txt'), largeBody);
    execFileSync('git', ['add', 'src/large-review-target.txt'], {
      cwd: projectRoot,
      stdio: 'pipe',
    });

    const outcome = await runCompiledFlow({
      runFolder,
      flow,
      flowBytes: bytes,
      runId: RunId.parse('79000000-0000-0000-0000-000000000006'),
      goal: 'review the current large staged diff',
      depth: 'standard',
      change_kind: change_kind(),
      now: deterministicNow(Date.UTC(2026, 3, 24, 14, 0, 0)),
      projectRoot,
      relayer: {
        connectorName: 'claude-code',
        relay: async (input: ClaudeCodeRelayInput): Promise<RelayResult> => {
          expect(input.prompt).toContain('"kind": "git-working-tree"');
          expect(input.prompt).toContain(`+${marker}-`);
          expect(input.prompt).not.toContain('ENOBUFS');
          return {
            request_payload: input.prompt,
            receipt_id: 'stub-receipt-review-large-diff',
            result_body: JSON.stringify({ verdict: 'NO_ISSUES_FOUND', findings: [] }),
            duration_ms: 1,
            cli_version: '0.0.0-stub',
          };
        },
      },
    });

    expect(outcome.result.outcome).toBe('complete');
    const intake = ReviewIntake.parse(
      JSON.parse(readFileSync(join(runFolder, 'reports', 'review-intake.json'), 'utf8')),
    );
    expect(intake.evidence.kind).toBe('git-working-tree');
    if (intake.evidence.kind !== 'git-working-tree') return;
    expect(intake.evidence.staged_diff.text).toContain(`+${marker}-`);
    expect(intake.evidence.staged_diff.text).not.toContain('ENOBUFS');
    expect(intake.evidence.staged_diff.truncated).toBe(true);
    expect(intake.evidence_warnings).toContainEqual(
      expect.objectContaining({ kind: 'diff_truncated' }),
    );
    const report = ReviewResult.parse(
      JSON.parse(readFileSync(join(runFolder, 'reports', 'review-result.json'), 'utf8')),
    );
    expect(report.evidence_warnings).toContainEqual(
      expect.objectContaining({ kind: 'diff_truncated' }),
    );
  });

  it('skips unreadable untracked files instead of aborting review intake', async () => {
    const { flow, bytes } = loadFixture();
    const runFolder = join(runFolderBase, 'unreadable-untracked-evidence');
    const projectRoot = join(runFolderBase, 'unreadable-project');
    const unreadablePath = join(projectRoot, 'unreadable.txt');
    mkdirSync(projectRoot, { recursive: true });
    execFileSync('git', ['init'], { cwd: projectRoot, stdio: 'pipe' });
    writeFileSync(unreadablePath, 'do not read me\n');
    chmodSync(unreadablePath, 0o000);

    try {
      const outcome = await runCompiledFlow({
        runFolder,
        flow,
        flowBytes: bytes,
        runId: RunId.parse('79000000-0000-0000-0000-000000000007'),
        goal: 'review the current untracked files',
        depth: 'standard',
        evidencePolicy: { includeUntrackedFileContent: true },
        change_kind: change_kind(),
        now: deterministicNow(Date.UTC(2026, 3, 24, 14, 0, 0)),
        projectRoot,
        relayer: relayerWith({ verdict: 'NO_ISSUES_FOUND', findings: [] }),
      });

      expect(outcome.result.outcome).toBe('complete');
      const intake = ReviewIntake.parse(
        JSON.parse(readFileSync(join(runFolder, 'reports', 'review-intake.json'), 'utf8')),
      );
      expect(intake.evidence.kind).toBe('git-working-tree');
      if (intake.evidence.kind !== 'git-working-tree') return;
      const unreadable = intake.evidence.untracked_files.find(
        (file) => file.path === 'unreadable.txt',
      );
      expect(unreadable?.content).toBeUndefined();
      expect(unreadable?.skipped_reason).toMatch(/failed to read|permission|EACCES/i);
      expect(intake.evidence_warnings).toContainEqual(
        expect.objectContaining({ kind: 'untracked_file_skipped', path: 'unreadable.txt' }),
      );
      const report = ReviewResult.parse(
        JSON.parse(readFileSync(join(runFolder, 'reports', 'review-result.json'), 'utf8')),
      );
      expect(report.evidence_warnings).toContainEqual(
        expect.objectContaining({ kind: 'untracked_file_skipped', path: 'unreadable.txt' }),
      );
    } finally {
      chmodSync(unreadablePath, 0o600);
    }
  });

  it('skips binary untracked files and truncates large untracked text after opt-in', async () => {
    const { flow, bytes } = loadFixture();
    const runFolder = join(runFolderBase, 'untracked-content-redaction');
    const projectRoot = join(runFolderBase, 'redaction-project');
    mkdirSync(projectRoot, { recursive: true });
    execFileSync('git', ['init'], { cwd: projectRoot, stdio: 'pipe' });
    writeFileSync(join(projectRoot, 'binary.dat'), Buffer.from([0x61, 0x00, 0x62]));
    writeFileSync(join(projectRoot, 'large.txt'), `${'x'.repeat(25_000)}\n`);

    const outcome = await runCompiledFlow({
      runFolder,
      flow,
      flowBytes: bytes,
      runId: RunId.parse('79000000-0000-0000-0000-000000000011'),
      goal: 'review the current untracked files',
      depth: 'standard',
      evidencePolicy: { includeUntrackedFileContent: true },
      change_kind: change_kind(),
      now: deterministicNow(Date.UTC(2026, 3, 24, 14, 0, 0)),
      projectRoot,
      relayer: relayerWith({ verdict: 'NO_ISSUES_FOUND', findings: [] }),
    });

    expect(outcome.result.outcome).toBe('complete');
    const intake = ReviewIntake.parse(
      JSON.parse(readFileSync(join(runFolder, 'reports', 'review-intake.json'), 'utf8')),
    );
    expect(intake.evidence.kind).toBe('git-working-tree');
    if (intake.evidence.kind !== 'git-working-tree') return;
    expect(intake.evidence.untracked_content_policy).toBe('include-content');
    expect(intake.evidence.untracked_files).toContainEqual(
      expect.objectContaining({
        path: 'binary.dat',
        skipped_reason: 'binary file skipped',
      }),
    );
    expect(
      intake.evidence.untracked_files.find((file) => file.path === 'binary.dat')?.content,
    ).toBeUndefined();
    const large = intake.evidence.untracked_files.find((file) => file.path === 'large.txt');
    expect(large?.content?.truncated).toBe(true);
    expect(large?.content?.text).toContain('[truncated');
    expect(intake.evidence_warnings).toContainEqual(
      expect.objectContaining({ kind: 'untracked_file_skipped', path: 'binary.dat' }),
    );
  });

  it('surfaces unavailable evidence as an explicit warning in intake and result', async () => {
    const { flow, bytes } = loadFixture();
    const runFolder = join(runFolderBase, 'unavailable-evidence-warning');
    const progress: ProgressEvent[] = [];

    const outcome = await runCompiledFlow({
      runFolder,
      flow,
      flowBytes: bytes,
      runId: RunId.parse('79000000-0000-0000-0000-000000000008'),
      goal: 'review without project root evidence',
      depth: 'standard',
      change_kind: change_kind(),
      now: deterministicNow(Date.UTC(2026, 3, 24, 14, 0, 0)),
      relayer: relayerWith({ verdict: 'NO_ISSUES_FOUND', findings: [] }),
      progress: (event) => progress.push(ProgressEvent.parse(event)),
    });

    expect(outcome.result.outcome).toBe('complete');
    const intake = ReviewIntake.parse(
      JSON.parse(readFileSync(join(runFolder, 'reports', 'review-intake.json'), 'utf8')),
    );
    expect(intake.evidence_warnings).toContainEqual(
      expect.objectContaining({ kind: 'evidence_unavailable' }),
    );
    const report = ReviewResult.parse(
      JSON.parse(readFileSync(join(runFolder, 'reports', 'review-result.json'), 'utf8')),
    );
    expect(report.evidence_warnings).toContainEqual(
      expect.objectContaining({ kind: 'evidence_unavailable' }),
    );
    expect(progress).toContainEqual(
      expect.objectContaining({
        type: 'evidence.warning',
        warning_kind: 'evidence_unavailable',
        display: expect.objectContaining({ tone: 'warning' }),
      }),
    );
  });

  it('derives the analyze result path from the live flow graph', async () => {
    const renamedResultPath = 'stages/analyze/review-findings-renamed.json';
    const { flow, bytes } = loadFixtureWithRenamedAnalyzeResultPath(renamedResultPath);
    const runFolder = join(runFolderBase, 'renamed-analyze-result-path');
    const goal = 'Review scope with renamed analyze result path';
    const relay = {
      verdict: 'ISSUES_FOUND',
      findings: [
        {
          severity: 'low',
          id: 'LOW-1',
          text: 'Low severity issue found by the reviewer.',
          file_refs: ['src/example.ts:22'],
        },
      ],
    } satisfies ReviewRelayResult;

    const outcome = await runCompiledFlow({
      runFolder,
      flow,
      flowBytes: bytes,
      runId: RunId.parse('79000000-0000-0000-0000-000000000003'),
      goal,
      depth: 'standard',
      change_kind: change_kind(),
      now: deterministicNow(Date.UTC(2026, 3, 24, 14, 0, 0)),
      relayer: relayerWith(relay),
    });

    expect(outcome.result.outcome).toBe('complete');
    expect(existsSync(join(runFolder, renamedResultPath))).toBe(true);
    expect(existsSync(join(runFolder, 'stages', 'analyze', 'review-raw-findings.json'))).toBe(
      false,
    );

    const report = ReviewResult.parse(
      JSON.parse(readFileSync(join(runFolder, 'reports', 'review-result.json'), 'utf8')),
    );
    expect(report.scope).toBe(goal);
    expect(report.findings).toEqual(relay.findings);
    expect(report.verdict).toBe('CLEAN');
  });

  it('aborts instead of throwing when the admitted relay result is not review-shaped', async () => {
    const { flow, bytes } = loadFixture();
    const runFolder = join(runFolderBase, 'bad-review-relay-shape');

    const outcome = await runCompiledFlow({
      runFolder,
      flow,
      flowBytes: bytes,
      runId: RunId.parse('79000000-0000-0000-0000-000000000004'),
      goal: 'Review scope with malformed admitted relay body',
      depth: 'standard',
      change_kind: change_kind(),
      now: deterministicNow(Date.UTC(2026, 3, 24, 14, 0, 0)),
      relayer: relayerWithBody('{"verdict":"NO_ISSUES_FOUND","findings":"not-an-array"}'),
    });

    expect(outcome.result.outcome).toBe('aborted');
    expect(outcome.result.reason).toContain("compose step 'verdict-step': report writer failed");
    expect(existsSync(join(runFolder, 'reports', 'review-result.json'))).toBe(false);

    const verdictCheck = outcome.trace_entries.find(
      (trace_entry) =>
        trace_entry.kind === 'check.evaluated' && trace_entry.step_id === 'verdict-step',
    );
    if (verdictCheck?.kind !== 'check.evaluated')
      throw new Error('expected verdict check trace_entry');
    expect(verdictCheck.check_kind).toBe('schema_sections');
    expect(verdictCheck.outcome).toBe('fail');

    expect(outcome.trace_entries.map(traceEntryLabel)).toEqual([
      'run.bootstrapped',
      'step.entered:intake-step',
      'step.report_written:intake-step',
      'check.evaluated:intake-step',
      'step.completed:intake-step',
      'step.entered:audit-step',
      'relay.started:audit-step',
      'relay.request:audit-step',
      'relay.receipt:audit-step',
      'relay.result:audit-step',
      'relay.completed:audit-step',
      'check.evaluated:audit-step',
      'step.completed:audit-step',
      'step.entered:verdict-step',
      'check.evaluated:verdict-step',
      'step.aborted:verdict-step',
      'run.closed',
    ]);
  });

  it.each(CASES)(
    'runs the live review fixture end-to-end for $name',
    async ({ name, runId, relay, expectedVerdict }) => {
      const { flow, bytes } = loadFixture();
      const runFolder = join(runFolderBase, name.replaceAll(' ', '-'));
      const goal = `Review scope for ${name}`;

      const outcome = await runCompiledFlow({
        runFolder,
        flow,
        flowBytes: bytes,
        runId: RunId.parse(runId),
        goal,
        depth: 'standard',
        change_kind: change_kind(),
        now: deterministicNow(Date.UTC(2026, 3, 24, 14, 0, 0)),
        relayer: relayerWith(relay),
      });

      expect(outcome.result.outcome).toBe('complete');

      const rawRelayPath = join(runFolder, 'stages', 'analyze', 'review-raw-findings.json');
      expect(existsSync(rawRelayPath)).toBe(true);
      expect(ReviewRelayResult.parse(JSON.parse(readFileSync(rawRelayPath, 'utf8')))).toEqual(
        relay,
      );

      const reportPath = join(runFolder, 'reports', 'review-result.json');
      expect(existsSync(reportPath)).toBe(true);
      const report = ReviewResult.parse(JSON.parse(readFileSync(reportPath, 'utf8')));
      expect(report.scope).toBe(goal);
      expect(report.findings).toEqual(relay.findings);
      expect(report.verdict).toBe(expectedVerdict);
      expect(report.verdict).toBe(computeReviewVerdict(report.findings));

      const relayCompleted = outcome.trace_entries.find(
        (trace_entry) => trace_entry.kind === 'relay.completed',
      );
      if (relayCompleted?.kind !== 'relay.completed') {
        throw new Error('expected relay.completed');
      }
      expect(relayCompleted.verdict).toBe(relay.verdict);

      const reviewCheck = outcome.trace_entries.find(
        (trace_entry) =>
          trace_entry.kind === 'check.evaluated' && trace_entry.step_id === 'audit-step',
      );
      if (reviewCheck?.kind !== 'check.evaluated') {
        throw new Error('expected review check.evaluated trace_entry');
      }
      expect(reviewCheck.check_kind).toBe('result_verdict');
      expect(reviewCheck.outcome).toBe('pass');

      // The analyze stage is a relay stage, so its durable report
      // evidence is relay.result rather than step.report_written.
      // The sequence below proves frame -> analyze -> close execution
      // and the expected trace_entry ordering for each stage.
      expect(outcome.trace_entries.map(traceEntryLabel)).toEqual([
        'run.bootstrapped',
        'step.entered:intake-step',
        'step.report_written:intake-step',
        'check.evaluated:intake-step',
        'step.completed:intake-step',
        'step.entered:audit-step',
        'relay.started:audit-step',
        'relay.request:audit-step',
        'relay.receipt:audit-step',
        'relay.result:audit-step',
        'relay.completed:audit-step',
        'check.evaluated:audit-step',
        'step.completed:audit-step',
        'step.entered:verdict-step',
        'step.report_written:verdict-step',
        'check.evaluated:verdict-step',
        'step.completed:verdict-step',
        'run.closed',
      ]);
    },
  );
});
