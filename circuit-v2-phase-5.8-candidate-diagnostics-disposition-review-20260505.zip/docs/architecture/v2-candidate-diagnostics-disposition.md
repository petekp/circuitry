# Core-v2 Candidate Diagnostics Disposition

Date: 2026-05-05

## Summary

Phase 5.8 decides the status of `CIRCUIT_V2_RUNTIME_CANDIDATE=1` without
renaming or removing it.

Decision:

```text
CIRCUIT_V2_RUNTIME_CANDIDATE=1 stays for now as a temporary migration diagnostic.
It is no longer a separate support-matrix expansion mechanism.
It should be renamed later to a runtime-decision diagnostics flag.
The rename should be a dedicated follow-up slice with compatibility tests.
```

This does not approve old runtime deletion.

## Current Behavior

The candidate support matrix currently aliases the default support matrix:

```ts
const V2_RUNTIME_CANDIDATE_SUPPORT_MATRIX = V2_RUNTIME_SUPPORT_MATRIX;
```

That means candidate mode does not add rows beyond normal default routing.

Today it mainly controls whether CLI JSON output includes:

```text
runtime
runtime_reason
```

Current behavior to preserve until a rename slice:

| Invocation | Behavior |
|---|---|
| candidate plus supported fresh run | routes through core-v2 and includes `runtime: "v2"` plus `runtime_reason` |
| candidate plus unsupported fresh run | stays retained and includes `runtime: "retained"` plus `runtime_reason` |
| candidate plus arbitrary explicit fixture | stays retained unless the fixture resolves under `generated/flows` |
| candidate plus `composeWriter` | stays retained because `composeWriter` is retained-runtime-only compatibility |
| candidate plus checkpoint resume | follows the saved run folder engine marker and includes runtime fields |

Strict v2 remains the fail-closed experiment lane. Rollback remains the operator
safety lane.

## Inventory Command

This command was run before writing this document so the inventory would not
include the new Phase 5.8 disposition files themselves:

```bash
rg -n "CIRCUIT_V2_RUNTIME_CANDIDATE|useV2RuntimeCandidate|candidate diagnostics|runtime_reason|runtimeOutputFields" \
  src tests scripts docs specs README.md commands plugins .claude-plugin generated package.json
```

## Consumer Classification

| File | Classification | Disposition |
|---|---|---|
| `src/cli/circuit.ts` | selector implementation and diagnostic output | Owns `useV2RuntimeCandidate()`, the candidate support matrix alias, and `runtimeOutputFields(...)`. Keep current behavior until a dedicated rename slice. |
| `tests/runner/cli-v2-runtime.test.ts` | test coverage | Proves candidate-supported rows emit v2 runtime diagnostics, unsupported rows emit retained diagnostics, arbitrary explicit fixtures remain retained, generated-flow fixtures can route through v2, and candidate plus `composeWriter` remains retained. Keep. |
| `tests/soak/v2-runtime-surface.test.ts` | test support and adjacent assertions | Resets candidate mode in the shared helper and proves default outputs omit runtime fields. It does not use candidate mode as a separate routing expansion. Keep. |
| `tests/runner/config-loader.test.ts` | test isolation | Clears `CIRCUIT_V2_RUNTIME_CANDIDATE` so rollback/config behavior is not polluted by ambient environment. Keep. |
| `tests/core-v2/checkpoint-resume-v2.test.ts` | saved-engine resume coverage | Uses runtime output fields in a rollback resume assertion, not candidate-specific logic. Keep. |
| `tests/runner/build-checkpoint-exec.test.ts` | retained resume coverage | Uses runtime output fields in a strict retained resume assertion, not candidate-specific logic. Keep. |
| `docs/architecture/v2-fallback-api-disposition-review.md` | review history | Asked whether candidate diagnostics should be kept, renamed, or removed. Superseded by this disposition. |
| `docs/architecture/v2-deletion-plan.md` | current migration policy | Should record that Phase 5.8 keeps the flag temporarily and recommends a later rename. |
| `docs/architecture/v2-worklog.md` | worklog/history | Should record this checkpoint. |
| old checkpoint docs and import inventories | documentation/history | Keep as historical context. Do not treat them as live runtime consumers. |

No `scripts/`, `commands/`, `plugins/`, `.claude-plugin/`, `generated/`, specs,
or README files are live candidate diagnostics consumers in the current
inventory.

## Product Status

`CIRCUIT_V2_RUNTIME_CANDIDATE=1` is still useful during the migration because
it asks the CLI to show how runtime selection was decided.

The name is now stale. The flag no longer means "try candidate rows that default
routing will not use." It means "show runtime decision diagnostics while keeping
the current selector policy."

Recommended future name:

```text
CIRCUIT_SHOW_RUNTIME_DECISION=1
```

An acceptable alternative is:

```text
CIRCUIT_RUNTIME_DIAGNOSTICS=1
```

The first name is clearer because the current output is specifically
`runtime` and `runtime_reason`, not a broad diagnostics bundle.

## Future Rename Slice

Do not rename the variable in Phase 5.8.

If the review approves this disposition, Phase 5.8.1 should:

- introduce `CIRCUIT_SHOW_RUNTIME_DECISION=1`;
- decide whether `CIRCUIT_V2_RUNTIME_CANDIDATE=1` remains as a temporary alias
  or is removed immediately;
- update CLI usage text;
- update tests for the new flag and any compatibility window;
- decide combined-flag diagnostic precedence when rollback and diagnostics are
  both set;
- keep strict v2 fail-closed behavior unchanged;
- keep arbitrary fixture and `composeWriter` routing unchanged.

My recommendation is a short compatibility window:

```text
CIRCUIT_SHOW_RUNTIME_DECISION=1 -> preferred diagnostic flag
CIRCUIT_V2_RUNTIME_CANDIDATE=1 -> temporary alias with identical behavior
```

Remove the old name only after a release note or explicit operator-facing
decision.

## Deletion Implication

Candidate diagnostics do not make the old runtime deletable.

Renaming or removing this flag would only change diagnostic output controls. It
would not migrate:

- retained/v1 checkpoint folders;
- unsupported public modes;
- arbitrary explicit fixtures;
- programmatic `composeWriter`;
- rollback;
- release proof compose writing;
- old runner/handler oracle tests;
- retained trace/reducer/snapshot/progress infrastructure.

## Non-Approvals

Phase 5.8 does not approve:

- renaming or removing `CIRCUIT_V2_RUNTIME_CANDIDATE`;
- adding `CIRCUIT_SHOW_RUNTIME_DECISION`;
- old runtime deletion;
- changing arbitrary fixture routing;
- changing `composeWriter` behavior;
- removing rollback;
- routing more modes through core-v2;
- moving connector subprocesses, relay materialization, registries, router,
  catalog, compiler, trace, reducer, snapshot, progress, checkpoint, runner, or
  handler internals.

## Stop Point

Stop here for external review.

The next possible slice is Phase 5.8.1, a candidate diagnostics rename with a
clear compatibility decision.
