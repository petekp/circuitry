import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { describe, expect, it } from 'vitest';
import {
  deriveRetainedSnapshot,
  readRetainedRunTrace,
  reduceRetainedRunTrace,
  resumeRetainedCompiledFlowCheckpoint,
  runRetainedCompiledFlow,
} from '../../src/compat/retained-runtime.js';

describe('retained runtime compatibility facade', () => {
  it('exposes the retained execution and v1 run-folder operations through one neutral module', () => {
    expect(typeof runRetainedCompiledFlow).toBe('function');
    expect(typeof resumeRetainedCompiledFlowCheckpoint).toBe('function');
    expect(typeof deriveRetainedSnapshot).toBe('function');
    expect(typeof readRetainedRunTrace).toBe('function');
    expect(typeof reduceRetainedRunTrace).toBe('function');

    const facade = readFileSync(resolve('src/compat/retained-runtime.ts'), 'utf8');
    expect(facade).toContain('../runtime/runner.js');
    expect(facade).toContain('../runtime/snapshot-writer.js');
    expect(facade).toContain('../runtime/trace-reader.js');
    expect(facade).toContain('../runtime/reducer.js');
  });

  it('keeps CLI and status surfaces off direct retained runtime imports', () => {
    const cli = readFileSync(resolve('src/cli/circuit.ts'), 'utf8');
    expect(cli).toContain('../compat/retained-runtime.js');
    expect(cli).not.toContain('../runtime/runner.js');
    expect(cli).toContain('runRetainedCompiledFlow');
    expect(cli).toContain('resumeRetainedCompiledFlowCheckpoint');

    const handoff = readFileSync(resolve('src/cli/handoff.ts'), 'utf8');
    expect(handoff).toContain('../compat/retained-runtime.js');
    expect(handoff).not.toContain('../runtime/snapshot-writer.js');

    const runStatusDispatcher = readFileSync(
      resolve('src/run-status/project-run-folder.ts'),
      'utf8',
    );
    expect(runStatusDispatcher).toContain('../compat/retained-runtime.js');
    expect(runStatusDispatcher).not.toContain('../runtime/trace-reader.js');

    const v1Projection = readFileSync(resolve('src/run-status/v1-run-folder.ts'), 'utf8');
    expect(v1Projection).toContain('../compat/retained-runtime.js');
    expect(v1Projection).not.toContain('../runtime/reducer.js');
  });
});
