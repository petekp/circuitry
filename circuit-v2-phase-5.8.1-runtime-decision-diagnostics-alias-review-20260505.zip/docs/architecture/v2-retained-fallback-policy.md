# Core-v2 Retained Fallback Policy

Date: 2026-05-05

## Decision

The retained runtime is now an intentional compatibility and fallback layer.

It is not the normal owner for proven fresh-run rows. It is also not dead code.
Each retained behavior needs an explicit product disposition before deletion.

## Current Classification

| Behavior | Current owner | Policy | Why |
|---|---|---|---|
| Matrix-supported fresh runs except checkpoint rows not yet proven | core-v2 | Default path | This is the normal v2 selector milestone. |
| Build deep fresh runs | core-v2 | Default path | Phase 5.3 proved checkpoint wait/resume/status/progress/result. |
| Retained/v1 checkpoint folders | retained runtime | Compatibility support | Saved run-folder identity wins. Old waiting folders should not be rewritten by fresh-run flags. |
| Checkpoint/tournament modes not in v2 matrix | retained runtime | Temporary compatibility until each mode is proven or retired | Needs mode-specific proof before default routing. |
| Unsupported flow/mode/depth fallback | retained runtime | Intentional fallback for now | Preserves permissive public CLI behavior while v2 support remains narrow. |
| Arbitrary explicit fixtures | retained runtime by default | Intentional fallback for now | Arbitrary fixtures may use shapes not proven by core-v2. Strict v2 remains the experimental override. |
| Programmatic `composeWriter` injection | retained runtime | Retained-runtime-only compatibility | Phase 5.7 keeps exported `main(..., { composeWriter })` support on retained runtime. Core-v2 does not get an equivalent hook. Internal v2 customization should use executor injection or generated reports. |
| Rollback | retained runtime | Operator safety feature | `CIRCUIT_DISABLE_V2_RUNTIME=1` must keep a known fallback while v2 expands. |
| Runtime decision diagnostics | CLI runtime output | Preferred flag with temporary alias | Phase 5.8.1 adds `CIRCUIT_SHOW_RUNTIME_DECISION=1` and keeps `CIRCUIT_V2_RUNTIME_CANDIDATE=1` as a temporary alias. Diagnostics report the actual selected runtime reason. |
| Old runner/handler oracle tests | retained tests | Keep until each behavior is v2-owned or intentionally retired | They still prove compatibility and fallback behavior. |

## Build Tournament Clarification

There is no current public Build tournament entry mode in the Build schematic or
generated Build flow.

Current Build entry modes are:

```text
default
lite
deep
autonomous
```

Phase 5.3 routes only Build deep to core-v2 by default. Build autonomous remains
retained by default. If a Build tournament mode is introduced later, it must get
its own selector proof before v2 routing.

## Fresh Runs Versus Resume

Fresh-run selector flags decide how to start a new run.

Resume dispatch is different. It follows the saved run folder's engine marker:

```text
core-v2 folder -> core-v2 resume
retained/v1 folder -> retained resume
```

This prevents rollback, strict opt-in, or candidate flags from rewriting a
saved run's execution identity.

## Deletion Readiness Implications

Old runtime deletion remains blocked while any retained behavior is classified
as compatibility support, intentional fallback, or oracle coverage.

Deletion can be reconsidered only when every retained behavior is one of:

```text
migrated to core-v2
kept as a smaller explicit compatibility module
retired by product decision
obsolete with import/test proof
```

There should be no `unknown` rows in a deletion packet.

## Near-Term Actions

Before any deletion slice:

- create a current-only file disposition for every `src/runtime` file;
- classify old runner/handler tests as compatibility, fallback, oracle, or
  obsolete;
- keep arbitrary fixtures retained by default unless a future fixture policy
  review changes that boundary;
- treat programmatic `composeWriter` as retained-runtime-only compatibility;
- remove the old candidate diagnostics alias only in a dedicated
  operator-facing slice;
- decide whether rollback is a permanent operator safety feature;
- keep retained/v1 checkpoint folder support explicit.

Phase 5.5 completed the file and test inventory. Phase 5.6 packaged the
remaining fallback API questions for external review in
`docs/architecture/v2-fallback-api-disposition-review.md`. Phase 5.7 resolves
the `composeWriter` question in
`docs/architecture/v2-compose-writer-disposition.md`: keep it retained-only,
do not add a core-v2 equivalent, and prefer v2 executor injection for internal
customization. Phase 5.8 resolves candidate diagnostics in
`docs/architecture/v2-candidate-diagnostics-disposition.md`, and Phase 5.8.1
implements the alias: `CIRCUIT_SHOW_RUNTIME_DECISION=1` is preferred, while
`CIRCUIT_V2_RUNTIME_CANDIDATE=1` remains temporarily supported.

## What Not To Do Next

Do not keep widening routes mechanically. Build deep was the obvious public
checkpoint row. The remaining retained surface is mostly compatibility policy,
fallback behavior, and deletion-readiness work.

Do not delete or move retained runtime infrastructure from this policy alone.
