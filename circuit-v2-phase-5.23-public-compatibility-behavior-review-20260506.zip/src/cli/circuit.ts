import { randomUUID } from 'node:crypto';
import { existsSync, readFileSync } from 'node:fs';
import { relative, resolve } from 'node:path';

import { resumeRetainedCompiledFlowCheckpoint } from '../compat/retained-checkpoint-folders.js';
import {
  type ChildCompiledFlowResolver,
  type CompiledFlowInvocation,
  type ComposeWriterFn,
  type RelayFn,
  runRetainedCompiledFlow,
} from '../compat/retained-runtime.js';
import type { ExecutorRegistryV2 } from '../core-v2/executors/index.js';
import { isCoreV2RunFolder, resumeCompiledFlowV2 } from '../core-v2/run/checkpoint-resume.js';
import type { ChildCompiledFlowResolverV2 } from '../core-v2/run/child-runner.js';
import { runCompiledFlowV2WithWaiting } from '../core-v2/run/compiled-flow-runner.js';
import { isGraphCheckpointWaitingResultV2 } from '../core-v2/run/graph-runner.js';
import type { ChangeKindDeclaration } from '../schemas/change-kind.js';
import { CompiledFlow } from '../schemas/compiled-flow.js';
import { Depth } from '../schemas/depth.js';
import { CompiledFlowId, RunId } from '../schemas/ids.js';
import { computeManifestHash } from '../schemas/manifest.js';
import {
  type ProgressDisplay,
  ProgressEvent,
  type ProgressEvent as ProgressEventValue,
} from '../schemas/progress-event.js';
import { RunResult } from '../schemas/result.js';

import { classifyCompiledFlowTask } from '../runtime/router.js';
import { discoverConfigLayers } from '../shared/config-loader.js';
import { validateCompiledFlowKindPolicy } from '../shared/flow-kind-policy.js';
import { writeOperatorSummary } from '../shared/operator-summary-writer.js';
import { runResultPath } from '../shared/result-path.js';
import { runCreateCommand } from './create.js';
import { runHandoffCommand } from './handoff.js';
import { runRunsCommand } from './runs.js';
import {
  CLI_RUNTIME_ROUTING_POLICY,
  GENERATED_FLOW_MIRROR_ROOT_ENV,
  RUNTIME_POLICY_REASONS,
} from './runtime-compatibility-policy.js';

// Runtime CLI entry point — invoked through ./bin/circuit-next.
//
// Loads the named flow fixture at generated/flows/<flow-name>/circuit.json,
// parses it through the CompiledFlow schema, validates kind-canonical
// stage-set policy, composes the runtime boundary via the runner, and
// prints the <run-folder> path on success.
//
// Invocation-layer flags stay narrow (--goal, --depth, --run-folder,
// --fixture, --flow-root). The product path discovers user-global and
// project config files and supplies them as LayeredConfigs to the
// selection resolver.
//
// `--dry-run` fails closed. An earlier version accepted the flag as a
// no-op while still spawning the real connector — a safety bug. The
// flag stays rejected until real dry-run support lands.

const DEFAULT_RUNS_BASE = '.circuit-next/runs';
const MAX_PROGRESS_DISPLAY_TEXT_CHARS = 240;

type RuntimeSelectionKind = 'v2-supported' | 'old-runtime-required' | 'unsupported';
type RuntimeSelectionName = 'v2' | 'retained';

interface V2RuntimeSupportDecision {
  readonly kind: RuntimeSelectionKind;
  readonly flowId: string;
  readonly entryModeName: string;
  readonly depth: string;
  readonly reason: string;
}

interface V2RuntimeSupportRow {
  readonly entryModeName: string;
  readonly depth: string;
}

const V2_RUNTIME_SUPPORT_MATRIX: Record<string, readonly V2RuntimeSupportRow[]> = {
  review: [{ entryModeName: 'default', depth: 'standard' }],
  fix: [
    { entryModeName: 'default', depth: 'standard' },
    { entryModeName: 'lite', depth: 'lite' },
    { entryModeName: 'deep', depth: 'deep' },
    { entryModeName: 'autonomous', depth: 'autonomous' },
  ],
  build: [
    { entryModeName: 'default', depth: 'standard' },
    { entryModeName: 'lite', depth: 'lite' },
    { entryModeName: 'deep', depth: 'deep' },
    { entryModeName: 'autonomous', depth: 'autonomous' },
  ],
  explore: [
    { entryModeName: 'default', depth: 'standard' },
    { entryModeName: 'lite', depth: 'lite' },
    { entryModeName: 'deep', depth: 'deep' },
    { entryModeName: 'autonomous', depth: 'autonomous' },
    { entryModeName: 'tournament', depth: 'tournament' },
  ],
  migrate: [
    { entryModeName: 'default', depth: 'standard' },
    { entryModeName: 'deep', depth: 'deep' },
    { entryModeName: 'autonomous', depth: 'autonomous' },
  ],
  sweep: [
    { entryModeName: 'default', depth: 'standard' },
    { entryModeName: 'lite', depth: 'lite' },
    { entryModeName: 'deep', depth: 'deep' },
    { entryModeName: 'autonomous', depth: 'autonomous' },
  ],
};

const V2_RUNTIME_CANDIDATE_SUPPORT_MATRIX = V2_RUNTIME_SUPPORT_MATRIX;

interface ParsedArgs {
  command?: 'run' | 'resume';
  flowName?: string;
  goal?: string;
  depth?: Depth;
  depthProvided: boolean;
  entryMode?: string;
  runFolder?: string;
  fixturePath?: string;
  flowRoot?: string;
  checkpointChoice?: string;
  progress?: 'jsonl';
  includeUntrackedContent: boolean;
}

interface ResolvedCompiledFlowRoute {
  flowName: string;
  source: 'explicit' | 'classifier';
  reason: string;
  matched_signal?: string;
  inferredEntryModeName?: string;
  inferredEntryModeReason?: string;
}

interface ResolvedEntryModeSelection {
  entryModeName?: string;
  source?: 'explicit' | 'classifier';
  reason?: string;
}

export interface CliMainOptions {
  relayer?: RelayFn;
  composeWriter?: ComposeWriterFn;
  now?: () => Date;
  runId?: string;
  configHomeDir?: string;
  configCwd?: string;
  v2Executors?: Partial<ExecutorRegistryV2>;
}

export function usage(): string {
  return [
    'usage: circuit-next run [flow-name] --goal "<goal>" [--mode <default|lite|deep|autonomous>] [--depth <lite|standard|deep|tournament|autonomous>] [--run-folder <path>] [--fixture <path>] [--flow-root <path>] [--progress jsonl]',
    '       circuit-next resume --run-folder <path> --checkpoint-choice <choice> [--progress jsonl]',
    '       circuit-next runs show --run-folder <path> --json',
    '       circuit-next handoff [save|resume|done] [options]',
    '       circuit-next create --description "<flow idea>" [--name <slug>] [--publish --yes]',
    '',
    '`--mode` is the friendly alias for `--entry-mode`; supplying both forms of that option is an error.',
    '',
    'With an explicit flow name, loads generated/flows/<name>/circuit.json. Without one, classifies the free-form goal across the registered explore/review/fix/build/migrate/sweep flows and then composes the runtime boundary using the configured relay connector.',
    '',
    'Config: if present, loads ~/.config/circuit-next/config.yaml and ./.circuit/config.yaml from the current working directory into the selection resolver before relay.',
    '',
    'Note: `--dry-run` is not implemented and is rejected. An earlier version silently invoked the real connector while reporting dry_run:true, which is a safety bug; the flag stays rejected until real dry-run support lands.',
    '',
    CLI_RUNTIME_ROUTING_POLICY,
    '',
    'Review evidence: untracked file contents are omitted by default. Add `--include-untracked-content` only when those files are safe to relay to the configured worker.',
  ].join('\n');
}

function parseArgs(argv: readonly string[]): ParsedArgs {
  // Positional: first non-flag token is the flow name.
  let flowName: string | undefined;
  let command: 'run' | 'resume' | undefined;
  let goal: string | undefined;
  let depth: Depth | undefined;
  let depthProvided = false;
  let entryMode: string | undefined;
  let runFolder: string | undefined;
  let fixturePath: string | undefined;
  let flowRoot: string | undefined;
  let checkpointChoice: string | undefined;
  let progress: 'jsonl' | undefined;
  let includeUntrackedContent = false;

  for (let i = 0; i < argv.length; i++) {
    const tok = argv[i];
    if (tok === undefined) continue;
    if (tok === '--goal') {
      const next = argv[i + 1];
      if (next === undefined) throw new Error('--goal requires a value');
      goal = next;
      i += 1;
      continue;
    }
    if (tok === '--depth') {
      const next = argv[i + 1];
      if (next === undefined) throw new Error(`${tok} requires a value`);
      if (depthProvided) {
        throw new Error('supply --depth only once');
      }
      depth = Depth.parse(next);
      depthProvided = true;
      i += 1;
      continue;
    }
    if (tok === '--entry-mode' || tok === '--mode') {
      const next = argv[i + 1];
      if (next === undefined) throw new Error(`${tok} requires a value`);
      if (next.length === 0) throw new Error(`${tok} requires a non-empty value`);
      if (entryMode !== undefined) {
        throw new Error('use either --mode or --entry-mode, not both');
      }
      entryMode = next;
      i += 1;
      continue;
    }
    if (tok === '--run-folder') {
      const next = argv[i + 1];
      if (next === undefined) throw new Error(`${tok} requires a value`);
      if (runFolder !== undefined) {
        throw new Error('supply --run-folder only once');
      }
      runFolder = next;
      i += 1;
      continue;
    }
    if (tok === '--fixture') {
      const next = argv[i + 1];
      if (next === undefined) throw new Error('--fixture requires a value');
      fixturePath = next;
      i += 1;
      continue;
    }
    if (tok === '--flow-root') {
      const next = argv[i + 1];
      if (next === undefined) throw new Error('--flow-root requires a value');
      if (next.length === 0) throw new Error('--flow-root requires a non-empty value');
      if (flowRoot !== undefined) {
        throw new Error('supply --flow-root only once');
      }
      flowRoot = next;
      i += 1;
      continue;
    }
    if (tok === '--checkpoint-choice') {
      const next = argv[i + 1];
      if (next === undefined) throw new Error('--checkpoint-choice requires a value');
      checkpointChoice = next;
      i += 1;
      continue;
    }
    if (tok === '--progress') {
      const next = argv[i + 1];
      if (next === undefined) throw new Error('--progress requires a value');
      if (next !== 'jsonl') throw new Error("--progress only supports 'jsonl'");
      progress = 'jsonl';
      i += 1;
      continue;
    }
    if (tok === '--dry-run') {
      // Fail closed. An earlier version accepted the flag silently while
      // the real connector still ran. Re-enable once real dry-run support
      // lands (deterministic dry relayer + trace marker).
      throw new Error(
        '--dry-run is not currently implemented and is rejected. An earlier version silently invoked the real connector while reporting dry_run:true, which is a safety bug. The flag stays rejected until real dry-run support lands.',
      );
    }
    if (tok === '--include-untracked-content') {
      includeUntrackedContent = true;
      continue;
    }
    if (tok === '--help' || tok === '-h') {
      process.stdout.write(`${usage()}\n`);
      process.exit(0);
    }
    if (tok.startsWith('--')) {
      throw new Error(`unknown flag: ${tok}`);
    }
    if ((tok === 'run' || tok === 'resume') && flowName === undefined && command === undefined) {
      command = tok;
      continue;
    }
    if (flowName === undefined) {
      flowName = tok;
      continue;
    }
    throw new Error(`unexpected positional argument: ${tok}`);
  }

  if (command === 'resume' || checkpointChoice !== undefined) {
    if (command !== 'resume') {
      throw new Error('checkpoint resume must use the `resume` subcommand');
    }
    if (runFolder === undefined) throw new Error('--run-folder is required for checkpoint resume');
    if (checkpointChoice === undefined || checkpointChoice.length === 0) {
      throw new Error('--checkpoint-choice is required for checkpoint resume');
    }
    if (flowName !== undefined) {
      throw new Error('checkpoint resume loads the saved flow manifest; omit flow-name');
    }
    if (goal !== undefined) {
      throw new Error('checkpoint resume reuses the saved run goal; omit --goal');
    }
    if (fixturePath !== undefined) {
      throw new Error('checkpoint resume loads the saved flow manifest; omit --fixture');
    }
    if (flowRoot !== undefined) {
      throw new Error('checkpoint resume loads the saved flow manifest; omit --flow-root');
    }
    if (depthProvided) {
      throw new Error('checkpoint resume reuses the saved run depth; omit --depth');
    }
    if (entryMode !== undefined) {
      throw new Error('checkpoint resume reuses the saved flow position; omit --mode/--entry-mode');
    }
    if (includeUntrackedContent) {
      throw new Error(
        'checkpoint resume reuses the saved evidence policy; omit --include-untracked-content',
      );
    }
  } else if (goal === undefined || goal.length === 0) {
    throw new Error('--goal is required and must be non-empty');
  }

  const result: ParsedArgs = {
    depthProvided,
    includeUntrackedContent,
  };
  if (depth !== undefined) result.depth = depth;
  if (entryMode !== undefined) result.entryMode = entryMode;
  if (command !== undefined) result.command = command;
  if (goal !== undefined) result.goal = goal;
  if (flowName !== undefined) result.flowName = flowName;
  if (runFolder !== undefined) result.runFolder = runFolder;
  if (fixturePath !== undefined) result.fixturePath = fixturePath;
  if (flowRoot !== undefined) result.flowRoot = flowRoot;
  if (checkpointChoice !== undefined) result.checkpointChoice = checkpointChoice;
  if (progress !== undefined) result.progress = progress;
  return result;
}

function resolveFixturePath(
  flowName: string,
  modeName: string | undefined,
  override: string | undefined,
  flowRoot: string | undefined,
): string {
  if (override !== undefined) return resolve(override);
  const root = resolve(flowRoot ?? 'generated/flows');
  // When a mode is explicitly requested, prefer the per-mode file if the
  // schematic author emitted one. Schematics with route_overrides produce
  // <mode>.json siblings of circuit.json — see scripts/emit-flows.mjs.
  // Falls back to circuit.json otherwise.
  if (modeName !== undefined) {
    const perMode = resolve(root, flowName, `${modeName}.json`);
    if (existsSync(perMode)) return perMode;
  }
  return resolve(root, flowName, 'circuit.json');
}

function progressReporter(enabled: boolean): ((event: ProgressEventValue) => void) | undefined {
  if (!enabled) return undefined;
  return (event) => {
    const parsed = ProgressEvent.parse(event);
    process.stderr.write(`${JSON.stringify(parsed)}\n`);
  };
}

function progressDisplay(
  text: string,
  importance: ProgressDisplay['importance'],
  tone: ProgressDisplay['tone'],
): ProgressDisplay {
  if (text.length <= MAX_PROGRESS_DISPLAY_TEXT_CHARS) return { text, importance, tone };
  return {
    text: `${text.slice(0, MAX_PROGRESS_DISPLAY_TEXT_CHARS - 14)} [truncated]`,
    importance,
    tone,
  };
}

function resolveCompiledFlowRoute(args: ParsedArgs): ResolvedCompiledFlowRoute {
  if (args.flowName !== undefined) {
    return {
      flowName: args.flowName,
      source: 'explicit',
      reason: 'explicit flow positional argument',
    };
  }
  if (args.goal === undefined) {
    throw new Error('--goal is required when not resuming a checkpoint');
  }
  return classifyCompiledFlowTask(args.goal);
}

function resolveEntryModeSelection(
  args: ParsedArgs,
  route: ResolvedCompiledFlowRoute,
): ResolvedEntryModeSelection {
  if (args.entryMode !== undefined) {
    return {
      entryModeName: args.entryMode,
      source: 'explicit',
      reason: 'explicit --mode/--entry-mode argument',
    };
  }
  if (args.depthProvided) return {};
  if (route.inferredEntryModeName !== undefined) {
    return {
      entryModeName: route.inferredEntryModeName,
      source: 'classifier',
      ...(route.inferredEntryModeReason === undefined
        ? {}
        : { reason: route.inferredEntryModeReason }),
    };
  }
  return {};
}

function loadFixture(fixturePath: string): { flow: CompiledFlow; bytes: Buffer } {
  if (!existsSync(fixturePath)) {
    throw new Error(`flow fixture not found: ${fixturePath}`);
  }
  const bytes = readFileSync(fixturePath);
  const raw: unknown = JSON.parse(bytes.toString('utf8'));
  const flow = CompiledFlow.parse(raw);
  // Enforce flow-kind canonical stage-set policy at fixture load.
  // Validator: src/shared/flow-kind-policy.ts.
  const policy = validateCompiledFlowKindPolicy(flow);
  if (!policy.ok) {
    throw new Error(`flow fixture policy violation (${fixturePath}):\n  ${policy.reason}`);
  }
  return { flow, bytes };
}

function defaultChildCompiledFlowResolver(flowRoot: string | undefined): ChildCompiledFlowResolver {
  return (ref) => {
    const fixturePath = resolveFixturePath(
      ref.flow_id as unknown as string,
      ref.entry_mode as unknown as string | undefined,
      undefined,
      flowRoot,
    );
    return loadFixture(fixturePath);
  };
}

function defaultChildCompiledFlowResolverV2(
  flowRoot: string | undefined,
): ChildCompiledFlowResolverV2 {
  return (ref) => {
    const fixturePath = resolveFixturePath(ref.flowId, ref.entryMode, undefined, flowRoot);
    const { bytes } = loadFixture(fixturePath);
    return { flowBytes: bytes };
  };
}

function assertFixtureMatchesRoute(flow: CompiledFlow, route: ResolvedCompiledFlowRoute): void {
  const flowId = flow.id as unknown as string;
  if (flowId !== route.flowName) {
    throw new Error(
      `flow fixture id mismatch: selected flow '${route.flowName}' but fixture declares '${flowId}'`,
    );
  }
}

function selectedEntryMode(
  flow: CompiledFlow,
  entryModeSelection: ResolvedEntryModeSelection,
): CompiledFlow['entry_modes'][number] {
  const entryName = entryModeSelection.entryModeName;
  const entry =
    entryName === undefined
      ? flow.entry_modes[0]
      : flow.entry_modes.find((mode) => mode.name === entryName);
  if (entry === undefined) {
    throw new Error(
      entryName === undefined
        ? `flow '${flow.id}' declares no entry modes`
        : `flow '${flow.id}' declares no entry_mode named '${entryName}'`,
    );
  }
  return entry;
}

function selectedEntryModeName(
  flow: CompiledFlow,
  entryModeSelection: ResolvedEntryModeSelection,
): string {
  return selectedEntryMode(flow, entryModeSelection).name;
}

function selectedDepth(
  flow: CompiledFlow,
  args: ParsedArgs,
  entryModeSelection: ResolvedEntryModeSelection,
): string {
  if (args.depth !== undefined) return args.depth;
  return selectedEntryMode(flow, entryModeSelection).depth;
}

function classifyV2RuntimeSupport(input: {
  readonly flow: CompiledFlow;
  readonly args: ParsedArgs;
  readonly entryModeSelection: ResolvedEntryModeSelection;
  readonly supportMatrix?: Record<string, readonly V2RuntimeSupportRow[]>;
}): V2RuntimeSupportDecision {
  const flowId = input.flow.id as unknown as string;
  const entryModeName = selectedEntryModeName(input.flow, input.entryModeSelection);
  const depth = selectedDepth(input.flow, input.args, input.entryModeSelection);
  const rows = (input.supportMatrix ?? V2_RUNTIME_SUPPORT_MATRIX)[flowId];
  if (rows === undefined) {
    return {
      kind: 'old-runtime-required',
      flowId,
      entryModeName,
      depth,
      reason: `flow '${flowId}' is not in the v2 runtime support matrix`,
    };
  }

  const supported = rows.some((row) => row.entryModeName === entryModeName && row.depth === depth);
  if (supported) {
    return {
      kind: 'v2-supported',
      flowId,
      entryModeName,
      depth,
      reason: `v2 supports fresh ${flowId} entry mode '${entryModeName}' at depth '${depth}'`,
    };
  }

  const hasCheckpoint = input.flow.steps.some((step) => step.kind === 'checkpoint');
  if ((depth === 'deep' || depth === 'tournament') && hasCheckpoint) {
    return {
      kind: 'old-runtime-required',
      flowId,
      entryModeName,
      depth,
      reason: `checkpoint-waiting depth '${depth}' remains on the retained checkpoint runtime`,
    };
  }

  return {
    kind: 'old-runtime-required',
    flowId,
    entryModeName,
    depth,
    reason: `fresh ${flowId} entry mode '${entryModeName}' at depth '${depth}' is not v2-proven yet`,
  };
}

function pathIsInside(parent: string, child: string): boolean {
  const rel = relative(parent, child);
  return rel.length === 0 || (!rel.startsWith('..') && !rel.startsWith('/'));
}

function fixtureEligibleForCandidateV2(input: {
  readonly args: ParsedArgs;
  readonly fixturePath: string;
}): boolean {
  if (input.args.fixturePath === undefined && input.args.flowRoot === undefined) return true;
  const fixturePath = resolve(input.fixturePath);
  if (pathIsInside(resolve('generated', 'flows'), fixturePath)) return true;
  const mirrorRoot = process.env[GENERATED_FLOW_MIRROR_ROOT_ENV];
  if (mirrorRoot === undefined || mirrorRoot.length === 0 || input.args.flowRoot === undefined) {
    return false;
  }
  const trustedMirrorRoot = resolve(mirrorRoot);
  return (
    resolve(input.args.flowRoot) === trustedMirrorRoot &&
    pathIsInside(trustedMirrorRoot, fixturePath)
  );
}

function applyCandidateFixturePolicy(
  decision: V2RuntimeSupportDecision,
  input: {
    readonly args: ParsedArgs;
    readonly fixturePath: string;
  },
): V2RuntimeSupportDecision {
  if (decision.kind !== 'v2-supported') return decision;
  if (fixtureEligibleForCandidateV2(input)) return decision;
  return {
    ...decision,
    kind: 'old-runtime-required',
    reason: RUNTIME_POLICY_REASONS.externalFixtureOrRoot,
  };
}

function applyComposeWriterPolicy(
  decision: V2RuntimeSupportDecision,
  input: { readonly hasComposeWriter: boolean },
): V2RuntimeSupportDecision {
  if (decision.kind !== 'v2-supported' || !input.hasComposeWriter) return decision;
  return {
    ...decision,
    kind: 'old-runtime-required',
    reason: RUNTIME_POLICY_REASONS.composeWriter,
  };
}

function assertStrictV2FreshRunSupported(decision: V2RuntimeSupportDecision): void {
  if (decision.kind === 'v2-supported') return;
  throw new Error(
    `CIRCUIT_V2_RUNTIME=1 cannot route this invocation through v2: ${decision.reason}`,
  );
}

function useV2Runtime(): boolean {
  return process.env.CIRCUIT_V2_RUNTIME === '1';
}

function showRuntimeDecision(): boolean {
  return (
    process.env.CIRCUIT_SHOW_RUNTIME_DECISION === '1' ||
    process.env.CIRCUIT_V2_RUNTIME_CANDIDATE === '1'
  );
}

function disableDefaultV2Runtime(): boolean {
  return process.env.CIRCUIT_DISABLE_V2_RUNTIME === '1';
}

function disabledV2Decision(decision: V2RuntimeSupportDecision): V2RuntimeSupportDecision {
  return {
    ...decision,
    kind: 'old-runtime-required',
    reason: RUNTIME_POLICY_REASONS.rollback,
  };
}

function runtimeOutputFields(input: {
  readonly include: boolean;
  readonly runtime: RuntimeSelectionName;
  readonly decision: V2RuntimeSupportDecision;
}): { readonly runtime?: RuntimeSelectionName; readonly runtime_reason?: string } {
  if (!input.include) return {};
  return {
    runtime: input.runtime,
    runtime_reason: input.decision.reason,
  };
}

export async function main(argv: readonly string[], options: CliMainOptions = {}): Promise<number> {
  if (argv[0] === 'handoff') {
    return runHandoffCommand(argv.slice(1), {
      ...(options.now === undefined ? {} : { now: options.now }),
    });
  }
  if (argv[0] === 'create') {
    return runCreateCommand(argv.slice(1), {
      ...(options.now === undefined ? {} : { now: options.now }),
    });
  }
  if (argv[0] === 'runs') {
    return runRunsCommand(argv.slice(1));
  }

  let args: ParsedArgs;
  try {
    args = parseArgs(argv);
  } catch (err) {
    process.stderr.write(`error: ${(err as Error).message}\n`);
    return 2;
  }

  if (
    args.command === 'resume' &&
    args.runFolder !== undefined &&
    args.checkpointChoice !== undefined
  ) {
    const runFolder = resolve(args.runFolder);
    const progress = progressReporter(args.progress === 'jsonl');
    if (await isCoreV2RunFolder(runFolder)) {
      const v2Result = await resumeCompiledFlowV2({
        runDir: runFolder,
        selection: args.checkpointChoice,
        now: options.now ?? (() => new Date()),
        childCompiledFlowResolver: defaultChildCompiledFlowResolverV2(undefined),
        ...(options.v2Executors === undefined ? {} : { executors: options.v2Executors }),
        ...(options.relayer === undefined ? {} : { relayer: options.relayer }),
        ...(progress === undefined ? {} : { progress }),
      });
      const runResult = RunResult.parse(JSON.parse(readFileSync(v2Result.resultPath, 'utf8')));
      const operatorSummary = writeOperatorSummary({
        runFolder,
        runResult,
        route: {
          selectedFlow: runResult.flow_id as unknown as string,
        },
      });
      const resumeRuntimeFields =
        showRuntimeDecision() || useV2Runtime() || disableDefaultV2Runtime()
          ? {
              runtime: 'v2' as const,
              runtime_reason: RUNTIME_POLICY_REASONS.v2CheckpointResume,
            }
          : {};
      process.stdout.write(
        `${JSON.stringify(
          {
            schema_version: 1,
            run_id: runResult.run_id,
            flow_id: runResult.flow_id,
            run_folder: runFolder,
            outcome: runResult.outcome,
            trace_entries_observed: runResult.trace_entries_observed,
            result_path: v2Result.resultPath,
            ...resumeRuntimeFields,
            operator_summary_path: operatorSummary.jsonPath,
            operator_summary_markdown_path: operatorSummary.markdownPath,
          },
          null,
          2,
        )}\n`,
      );
      return 0;
    }
    const selectionConfigLayers = discoverConfigLayers({
      ...(options.configHomeDir !== undefined ? { homeDir: options.configHomeDir } : {}),
      ...(options.configCwd !== undefined ? { cwd: options.configCwd } : {}),
    });
    const outcome = await resumeRetainedCompiledFlowCheckpoint({
      runFolder,
      selection: args.checkpointChoice,
      projectRoot: resolve(options.configCwd ?? process.cwd()),
      now: options.now ?? (() => new Date()),
      ...(options.relayer === undefined ? {} : { relayer: options.relayer }),
      childCompiledFlowResolver: defaultChildCompiledFlowResolver(undefined),
      ...(progress === undefined ? {} : { progress }),
      ...(selectionConfigLayers.length === 0 ? {} : { selectionConfigLayers }),
    });
    const operatorSummary = writeOperatorSummary({
      runFolder: outcome.runFolder,
      runResult: outcome.result,
      route: {
        selectedFlow: outcome.result.flow_id as unknown as string,
      },
    });
    const resumeResultPath =
      outcome.result.outcome === 'checkpoint_waiting'
        ? {}
        : { result_path: runResultPath(outcome.runFolder) };
    const resumeRuntimeFields =
      showRuntimeDecision() || useV2Runtime() || disableDefaultV2Runtime()
        ? {
            runtime: 'retained' as const,
            runtime_reason: RUNTIME_POLICY_REASONS.retainedCheckpointResume,
          }
        : {};
    process.stdout.write(
      `${JSON.stringify(
        {
          schema_version: 1,
          run_id: outcome.result.run_id,
          flow_id: outcome.result.flow_id,
          run_folder: outcome.runFolder,
          outcome: outcome.result.outcome,
          trace_entries_observed: outcome.result.trace_entries_observed,
          ...resumeResultPath,
          ...resumeRuntimeFields,
          operator_summary_path: operatorSummary.jsonPath,
          operator_summary_markdown_path: operatorSummary.markdownPath,
          ...(outcome.result.outcome === 'checkpoint_waiting'
            ? { checkpoint: outcome.result.checkpoint }
            : {}),
        },
        null,
        2,
      )}\n`,
    );
    return 0;
  }

  if (args.goal === undefined) {
    throw new Error('internal error: --goal missing outside checkpoint resume mode');
  }

  const route = resolveCompiledFlowRoute(args);
  const entryModeSelection = resolveEntryModeSelection(args, route);
  const fixturePath = resolveFixturePath(
    route.flowName,
    entryModeSelection.entryModeName,
    args.fixturePath,
    args.flowRoot,
  );
  const { flow, bytes } = loadFixture(fixturePath);
  assertFixtureMatchesRoute(flow, route);
  const runId = RunId.parse(options.runId ?? randomUUID());
  const now = options.now ?? (() => new Date());
  const progress = progressReporter(args.progress === 'jsonl');
  progress?.({
    schema_version: 1,
    type: 'route.selected',
    run_id: runId,
    flow_id: flow.id,
    recorded_at: now().toISOString(),
    label: `Selected ${route.flowName}`,
    display: progressDisplay(
      entryModeSelection.entryModeName === undefined
        ? `Circuit selected ${route.flowName}: ${route.reason}`
        : `Circuit selected ${route.flowName} with ${entryModeSelection.entryModeName} thoroughness: ${route.reason}`,
      'major',
      'info',
    ),
    selected_flow: flow.id,
    routed_by: route.source,
    router_reason: route.reason,
    ...(route.matched_signal === undefined ? {} : { router_signal: route.matched_signal }),
    ...(entryModeSelection.entryModeName === undefined
      ? {}
      : { entry_mode: entryModeSelection.entryModeName }),
    ...(entryModeSelection.source === undefined
      ? {}
      : { entry_mode_source: entryModeSelection.source }),
  });
  const runFolder = resolve(args.runFolder ?? `${DEFAULT_RUNS_BASE}/${runId as unknown as string}`);
  const selectionConfigLayers = discoverConfigLayers({
    ...(options.configHomeDir !== undefined ? { homeDir: options.configHomeDir } : {}),
    ...(options.configCwd !== undefined ? { cwd: options.configCwd } : {}),
  });

  const change_kind: ChangeKindDeclaration = {
    change_kind: 'ratchet-advance',
    failure_mode: 'circuit flow invocation has no executable product proof',
    acceptance_evidence:
      'trace.ndjson + state.json + manifest.snapshot.json + reports/result.json from clean checkout',
    alternate_framing:
      'defer the runtime proof; not an option because the CLI is the proof harness and must produce a real run-folder per invocation.',
  };
  const projectRoot = resolve(options.configCwd ?? process.cwd());

  const invocation: CompiledFlowInvocation = {
    runFolder,
    flow,
    flowBytes: bytes,
    projectRoot,
    runId,
    goal: args.goal,
    change_kind,
    now,
  };
  if (args.depth !== undefined) invocation.depth = args.depth;
  if (entryModeSelection.entryModeName !== undefined) {
    invocation.entryModeName = entryModeSelection.entryModeName;
  }
  if (options.relayer !== undefined) invocation.relayer = options.relayer;
  if (options.composeWriter !== undefined) invocation.composeWriter = options.composeWriter;
  invocation.childCompiledFlowResolver = defaultChildCompiledFlowResolver(args.flowRoot);
  if (progress !== undefined) invocation.progress = progress;
  if (selectionConfigLayers.length > 0) {
    invocation.selectionConfigLayers = selectionConfigLayers;
  }
  if (args.includeUntrackedContent) {
    invocation.evidencePolicy = { includeUntrackedFileContent: true };
  }

  const runtimeSupport = classifyV2RuntimeSupport({ flow, args, entryModeSelection });
  const candidateSupport = classifyV2RuntimeSupport({
    flow,
    args,
    entryModeSelection,
    supportMatrix: V2_RUNTIME_CANDIDATE_SUPPORT_MATRIX,
  });
  const strictRuntimeSupport = applyComposeWriterPolicy(candidateSupport, {
    hasComposeWriter: options.composeWriter !== undefined,
  });
  const baseDefaultRuntimeSupport = applyComposeWriterPolicy(
    applyCandidateFixturePolicy(runtimeSupport, {
      args,
      fixturePath,
    }),
    { hasComposeWriter: options.composeWriter !== undefined },
  );
  const strictV2Runtime = useV2Runtime();
  const runtimeDecisionDiagnostics = showRuntimeDecision();
  const defaultV2RuntimeDisabled = disableDefaultV2Runtime();
  const defaultRuntimeSupport = defaultV2RuntimeDisabled
    ? disabledV2Decision(baseDefaultRuntimeSupport)
    : baseDefaultRuntimeSupport;
  if (strictV2Runtime) {
    assertStrictV2FreshRunSupported(strictRuntimeSupport);
  }
  const routeToV2 =
    (strictV2Runtime && strictRuntimeSupport.kind === 'v2-supported') ||
    (!strictV2Runtime &&
      !defaultV2RuntimeDisabled &&
      defaultRuntimeSupport.kind === 'v2-supported');

  if (routeToV2) {
    const v2Result = await runCompiledFlowV2WithWaiting({
      flowBytes: bytes,
      runDir: runFolder,
      runId,
      goal: args.goal,
      now,
      projectRoot,
      childCompiledFlowResolver: defaultChildCompiledFlowResolverV2(args.flowRoot),
      ...(args.depth === undefined ? {} : { depth: args.depth }),
      ...(entryModeSelection.entryModeName === undefined
        ? {}
        : { entryModeName: entryModeSelection.entryModeName }),
      ...(options.relayer === undefined ? {} : { relayer: options.relayer }),
      ...(options.v2Executors === undefined ? {} : { executors: options.v2Executors }),
      ...(selectionConfigLayers.length === 0 ? {} : { selectionConfigLayers }),
      ...(progress === undefined ? {} : { progress }),
      ...(args.includeUntrackedContent
        ? { evidencePolicy: { includeUntrackedFileContent: true } }
        : {}),
    });
    if (isGraphCheckpointWaitingResultV2(v2Result)) {
      const waitingResult = {
        schema_version: 1 as const,
        run_id: RunId.parse(v2Result.runId),
        flow_id: CompiledFlowId.parse(v2Result.flowId),
        goal: args.goal,
        outcome: 'checkpoint_waiting' as const,
        summary: `checkpoint '${v2Result.checkpoint.stepId}' is waiting for an operator choice.`,
        trace_entries_observed: v2Result.traceEntriesObserved,
        manifest_hash: computeManifestHash(bytes),
        checkpoint: {
          step_id: v2Result.checkpoint.stepId,
          request_path: v2Result.checkpoint.requestPath,
          allowed_choices: v2Result.checkpoint.allowedChoices,
        },
      };
      const operatorSummary = writeOperatorSummary({
        runFolder,
        runResult: waitingResult,
        route: {
          selectedFlow: route.flowName,
          routedBy: route.source,
          routerReason: route.reason,
        },
      });
      process.stdout.write(
        `${JSON.stringify(
          {
            schema_version: 1,
            run_id: waitingResult.run_id,
            flow_id: waitingResult.flow_id,
            selected_flow: route.flowName,
            routed_by: route.source,
            router_reason: route.reason,
            ...(route.matched_signal === undefined ? {} : { router_signal: route.matched_signal }),
            ...(entryModeSelection.entryModeName === undefined
              ? {}
              : { entry_mode: entryModeSelection.entryModeName }),
            ...(entryModeSelection.source === undefined
              ? {}
              : { entry_mode_source: entryModeSelection.source }),
            run_folder: runFolder,
            outcome: waitingResult.outcome,
            trace_entries_observed: waitingResult.trace_entries_observed,
            ...runtimeOutputFields({
              include: strictV2Runtime || runtimeDecisionDiagnostics,
              runtime: 'v2',
              decision: strictV2Runtime ? strictRuntimeSupport : defaultRuntimeSupport,
            }),
            operator_summary_path: operatorSummary.jsonPath,
            operator_summary_markdown_path: operatorSummary.markdownPath,
            checkpoint: waitingResult.checkpoint,
          },
          null,
          2,
        )}\n`,
      );
      return 0;
    }
    const runResult = RunResult.parse(JSON.parse(readFileSync(v2Result.resultPath, 'utf8')));
    const operatorSummary = writeOperatorSummary({
      runFolder,
      runResult,
      route: {
        selectedFlow: route.flowName,
        routedBy: route.source,
        routerReason: route.reason,
      },
    });
    process.stdout.write(
      `${JSON.stringify(
        {
          schema_version: 1,
          run_id: runResult.run_id,
          flow_id: runResult.flow_id,
          selected_flow: route.flowName,
          routed_by: route.source,
          router_reason: route.reason,
          ...(route.matched_signal === undefined ? {} : { router_signal: route.matched_signal }),
          ...(entryModeSelection.entryModeName === undefined
            ? {}
            : { entry_mode: entryModeSelection.entryModeName }),
          ...(entryModeSelection.source === undefined
            ? {}
            : { entry_mode_source: entryModeSelection.source }),
          run_folder: runFolder,
          outcome: runResult.outcome,
          trace_entries_observed: runResult.trace_entries_observed,
          result_path: v2Result.resultPath,
          ...runtimeOutputFields({
            include: strictV2Runtime || runtimeDecisionDiagnostics,
            runtime: 'v2',
            decision: strictV2Runtime ? strictRuntimeSupport : defaultRuntimeSupport,
          }),
          operator_summary_path: operatorSummary.jsonPath,
          operator_summary_markdown_path: operatorSummary.markdownPath,
        },
        null,
        2,
      )}\n`,
    );
    return 0;
  }

  const outcome = await runRetainedCompiledFlow(invocation);
  const operatorSummary = writeOperatorSummary({
    runFolder: outcome.runFolder,
    runResult: outcome.result,
    route: {
      selectedFlow: route.flowName,
      routedBy: route.source,
      routerReason: route.reason,
    },
  });
  const resultPath =
    outcome.result.outcome === 'checkpoint_waiting'
      ? {}
      : { result_path: runResultPath(outcome.runFolder) };

  process.stdout.write(
    `${JSON.stringify(
      {
        schema_version: 1,
        run_id: outcome.result.run_id,
        flow_id: outcome.result.flow_id,
        selected_flow: route.flowName,
        routed_by: route.source,
        router_reason: route.reason,
        ...(route.matched_signal === undefined ? {} : { router_signal: route.matched_signal }),
        ...(entryModeSelection.entryModeName === undefined
          ? {}
          : { entry_mode: entryModeSelection.entryModeName }),
        ...(entryModeSelection.source === undefined
          ? {}
          : { entry_mode_source: entryModeSelection.source }),
        run_folder: outcome.runFolder,
        outcome: outcome.result.outcome,
        trace_entries_observed: outcome.result.trace_entries_observed,
        ...resultPath,
        ...runtimeOutputFields({
          include: runtimeDecisionDiagnostics || defaultV2RuntimeDisabled,
          runtime: 'retained',
          decision: defaultRuntimeSupport,
        }),
        operator_summary_path: operatorSummary.jsonPath,
        operator_summary_markdown_path: operatorSummary.markdownPath,
        ...(outcome.result.outcome === 'checkpoint_waiting'
          ? { checkpoint: outcome.result.checkpoint }
          : {}),
      },
      null,
      2,
    )}\n`,
  );
  return 0;
}

const invokedDirectly =
  process.argv[1] !== undefined &&
  (import.meta.url === `file://${process.argv[1]}` ||
    import.meta.url.endsWith(process.argv[1].split('/').pop() ?? ''));

if (invokedDirectly) {
  main(process.argv.slice(2)).then(
    (code) => process.exit(code),
    (err: unknown) => {
      process.stderr.write(`error: ${err instanceof Error ? err.message : String(err)}\n`);
      process.exit(1);
    },
  );
}
