# Circuit v2 Selector Soak Report

Last updated: 2026-05-05.

## Scope

This report tracks the automated selector soak gate added in Phase 5.0.

The gate proves the current ownership boundary:

```text
core-v2 owns matrix-supported fresh runs.
retained runtime owns checkpoint resume, checkpoint-waiting depths,
unsupported modes, arbitrary fixtures, programmatic composeWriter fallback,
rollback, and old oracle coverage.
```

Phase 5.2.1 adds one candidate-only exception: Build deep can run through
core-v2 under `CIRCUIT_V2_RUNTIME_CANDIDATE=1` or `CIRCUIT_V2_RUNTIME=1`, but
it is not default-routed.

## Commands

Primary gates:

```bash
npm run soak:v2:fast
npm run soak:v2
```

Supporting focused command:

```bash
npx vitest run tests/soak
```

## Supported Matrix Rows

`tests/soak/v2-runtime-surface.test.ts` covers every default-routed
matrix-supported fresh run without v2 environment variables:

| Row | Proof |
|---|---|
| Review default | core-v2 trace marker, result parse, manifest/result hash agreement, `runs show --json`, operator summary files |
| Fix lite | core-v2 trace marker, result parse, manifest/result hash agreement, `runs show --json`, operator summary files |
| Build default | core-v2 trace marker, result parse, manifest/result hash agreement, `runs show --json`, operator summary files |
| Build lite | core-v2 trace marker, result parse, manifest/result hash agreement, `runs show --json`, operator summary files |
| Explore default | core-v2 trace marker, result parse, manifest/result hash agreement, `runs show --json`, operator summary files |
| Migrate default | core-v2 trace marker, result parse, manifest/result hash agreement, parent and child run consistency |
| Sweep default | core-v2 trace marker, result parse, manifest/result hash agreement, `runs show --json`, operator summary files |

## Candidate Rows

`tests/runner/cli-v2-runtime.test.ts` covers:

| Row | Proof |
|---|---|
| Build deep candidate | core-v2 trace marker, checkpoint wait, Build brief parse, `runs show --json` waiting status, checkpoint/user-input progress, saved project root restore, selection config restore, resume, result parse, Build result parse |

## Retained Fallback Rows

The soak suite checks retained execution for:

| Row | Proof |
|---|---|
| Fix default | retained v1 trace marker |
| Build deep checkpoint-waiting depth by default | retained v1 trace marker |
| Explore tournament | retained v1 trace marker |
| Arbitrary explicit fixture | retained v1 trace marker |
| Programmatic `composeWriter` | retained v1 trace marker and aborted retained result |
| Rollback for Review default | retained diagnostic output and retained v1 trace marker |
| Rollback for Fix lite | retained diagnostic output and retained v1 trace marker |
| Rollback for Build default | retained diagnostic output and retained v1 trace marker |

## Strict Opt-In

The soak suite checks:

- strict v2 opt-in routes a supported Review default run through core-v2 even
  when rollback is also set;
- strict v2 opt-in rejects unsupported Fix default before creating a run folder;
- strict v2 opt-in can route Build deep through the v2 checkpoint candidate path.

## Runs Show

The soak suite calls `runs show --json` for every core-v2 run in the default
matrix and checks:

- completed status;
- result path;
- flow id;
- terminal outcome.

Existing `tests/runner/run-status-projection.test.ts` remains the deeper
malformed trace, v1, v2, retry, aborted, and checkpoint-waiting projection
coverage.

## Progress JSONL

The soak suite parses every emitted progress line through `ProgressEvent` and
checks targeted lifecycle events for:

- Review relay progress;
- Build unsafe-connector abort progress;
- Migrate parent/child progress;
- fanout branch lifecycle progress.

## Connector Safety

The soak suite checks:

- unsafe Codex implementer configuration rejects before relayer invocation;
- a real custom connector bridge executes without an injected relayer;
- project custom connector config overrides user-global config.

Existing connector and relay tests remain the deeper provider/model,
materializer, identity, and schema-tagged report safety coverage.

## Child Runs And Fanout

The soak suite checks:

- Migrate default creates a Build child run;
- parent and child result/manifest/status consistency;
- child run folders do not need top-level operator summaries;
- fanout emits branch lifecycle progress;
- fanout aggregate and branch proposal reports parse.

## Known Gaps

The soak gate does not make retained checkpoint resume v2-owned. It proves that
retained/v1 checkpoint folders still stay retained, while Build deep has a
candidate-only v2 checkpoint path.

The soak gate does not approve old runtime deletion.

## Latest Results

Phase 5.0 validation:

- `npm run check`: passed.
- `npm run lint`: passed.
- `npm run build`: passed.
- `npx vitest run tests/soak`: passed.
- `npm run soak:v2:fast`: passed.
- `npm run soak:v2`: passed.
- `npm run test:fast`: passed.
- `npm run check-flow-drift`: passed on sequential rerun after `test:fast`.
- `npm run verify`: passed after report updates.
- `git diff --check`: passed.

`npm run soak:v2` ran the focused soak suite, full `npm run verify`, and
`npm run check-flow-drift` successfully.

Note: a parallel `npm run check-flow-drift` run overlapped with
`tests/unit/emit-flows-drift.test.ts` and briefly saw that test's temporary
stale sibling fixture. The generated files were clean after `test:fast`
finished, and the sequential drift rerun passed.
