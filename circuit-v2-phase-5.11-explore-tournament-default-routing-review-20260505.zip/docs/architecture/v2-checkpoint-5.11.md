# Phase 5.11 - Explore Tournament Default Routing

Date: 2026-05-05

## Summary

Phase 5.11 routes Explore tournament fresh runs through core-v2 by default.

This is a parity slice, not a deletion slice. It does not change arbitrary
fixtures, custom flow roots, rollback, retained/v1 checkpoint folders,
`composeWriter`, connector ownership, registry ownership, or old runtime
deletion.

## Behavior Changed

`src/cli/circuit.ts` now includes:

```text
explore + tournament depth -> core-v2 selector matrix
```

The route change is backed by a correctness hardening slice in v2 fanout:

- relay fanout branches with compiled-flow context use the production relay
  prompt path;
- branch prompts include synthetic step ids such as
  `proposal-fanout-step-option-1`;
- branch relay execution uses the public `relayer` when supplied;
- accepted branch reports run parse/schema, provenance, and cross-report
  validation before admission;
- rejected branch reports are not written;
- production relay fanout branches write retained-compatible `request.txt`,
  `receipt.txt`, `result.json`, and `report.json` artifacts.

V2 tournament checkpoint projection now enriches operator context from:

```text
reports/decision-options.json
reports/tournament-review.json
```

so progress JSONL and `runs show` expose real option labels and the tournament
tradeoff question instead of only generic option names.

## Files Changed

- `src/cli/circuit.ts`
- `src/core-v2/executors/relay.ts`
- `src/core-v2/fanout/branch-execution.ts`
- `src/core-v2/projections/progress.ts`
- `src/core-v2/projections/tournament-checkpoint-context.ts`
- `src/run-status/v2-run-folder.ts`
- `tests/core-v2/fanout-v2.test.ts`
- `tests/parity/explore-v2.test.ts`
- `tests/runner/cli-v2-runtime.test.ts`
- `tests/soak/v2-runtime-surface.test.ts`
- `docs/architecture/v2-checkpoint-5.11.md`
- `docs/architecture/v2-retained-fallback-policy.md`
- `docs/architecture/v2-deletion-readiness-inventory.md`
- `docs/architecture/v2-deletion-plan.md`
- `docs/architecture/v2-worklog.md`
- `HANDOFF.md`

## Proof

`tests/core-v2/fanout-v2.test.ts` proves:

- compiled relay fanout branches use production relayer prompts;
- invalid JSON, schema failures, provenance mismatches, and cross-report
  validator failures abort branches;
- rejected branches do not write admitted branch reports.

`tests/parity/explore-v2.test.ts` proves:

- generated `generated/flows/explore/tournament.json` reaches a v2 waiting
  checkpoint with normal v2 executors;
- four tournament branch reports are admitted and aggregated;
- tournament review writes the tradeoff question;
- progress and run-status projection show real option labels;
- marker-gated v2 resume with `option-2` writes final decision/result reports.

`tests/runner/cli-v2-runtime.test.ts` and `tests/soak/v2-runtime-surface.test.ts`
prove:

- `circuit-next run explore --mode tournament` defaults to core-v2;
- rollback still forces retained runtime;
- strict unsupported invocations still fail closed for unsupported flows;
- Explore tournament wait/resume closes through core-v2 in the CLI and soak
  surfaces.

## Non-Approvals

Phase 5.11 does not approve:

- old runtime deletion;
- arbitrary fixture or custom-root v2 default routing;
- `composeWriter` behavior changes;
- rollback removal;
- retained/v1 checkpoint folder migration;
- connector subprocess movement;
- relay materializer movement;
- registry, router, catalog, or compiler movement;
- trace, reducer, snapshot, progress, checkpoint, runner, or handler deletion.

## Validation

Passed in this checkpoint:

- `npx vitest run tests/core-v2/fanout-v2.test.ts tests/parity/explore-v2.test.ts`
- `npm run check`
- `npm run lint`
- `npm run build`
- `npx vitest run tests/core-v2/fanout-v2.test.ts tests/parity/explore-v2.test.ts tests/runner/cli-v2-runtime.test.ts tests/soak/v2-runtime-surface.test.ts`
- `npm run soak:v2:fast`
- `npx vitest run tests/runner/cli-router.test.ts tests/runner/cli-v2-runtime.test.ts tests/soak/v2-runtime-surface.test.ts`
- `npm run soak:v2`
- `git diff --check`

`npm run soak:v2` includes full `npm run verify` and `npm run check-flow-drift`.
The full run passed after adding explicit timeouts to long matrix-style runner
tests that exceeded Vitest's default 5 second limit under full-suite load.

## Next

The next external review should be narrow and post-implementation: verify the
Explore tournament route change and the fanout-relay hardening evidence.

After that, the next implementation choices should move from default routing to
the remaining deletion blockers: release proof `composeWriter`, retained/v1
checkpoint folder strategy, public compatibility API ownership, or neutral
ownership for connectors/registries. Do not start old runtime deletion yet.
